Put custom_wake_word.ppn here (trained at console.picovoice.ai, platform Android) to use a custom wake word.
