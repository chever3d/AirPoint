// AirPoint by Chever3d
package com.chever3d.airpoint.engine

import android.Manifest
import android.app.Notification
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.chever3d.airpoint.AirPointApp
import com.chever3d.airpoint.MainActivity
import com.chever3d.airpoint.R
import com.chever3d.airpoint.control.ControlBridge
import com.chever3d.airpoint.control.CursorStyle
import com.chever3d.airpoint.data.ConfigRepository
import com.chever3d.airpoint.wake.WakeWordListener
import kotlinx.coroutines.launch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Foreground service that owns the camera, the hand tracker, the gesture engine and the
 * wake-word listener.
 *
 *  ACTIVE  – camera ~20 fps, cursor + gestures live
 *  STANDBY – camera ~5 fps watching only for the wake gesture, and/or mic for the wake word
 *  OFF     – service stopped, zero battery
 *
 * Screen off always stops everything.
 */
class GestureEngineService : LifecycleService(), EngineHost {

    private lateinit var repo: ConfigRepository
    private val main = Handler(Looper.getMainLooper())
    private val engineExec: ExecutorService = Executors.newSingleThreadExecutor()
    private val cameraExec: ExecutorService = Executors.newSingleThreadExecutor()
    private val engine = GestureEngine(this)

    @Volatile private var tracker: HandTracker? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var cameraBound = false
    private var wakeWord: WakeWordListener? = null
    private var inForeground = false
    /** Mic may only be used if the service went foreground with the microphone type. */
    private var micTypeActive = false

    @Volatile private var lastProcessed = 0L
    private var fpsCount = 0
    private var fpsWindowStart = 0L

    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_SCREEN_OFF) shutdown()
        }
    }

    override fun onCreate() {
        super.onCreate()
        repo = ConfigRepository.get(this)
        lifecycleScope.launch {
            repo.config.collect { cfg ->
                engine.config = cfg
                // Wake-word setting changed while standing by: re-apply.
                if (EngineBus.mode.value == EngineMode.STANDBY) applyWakeWord(EngineMode.STANDBY)
            }
        }
        ContextCompat.registerReceiver(
            this, screenOffReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF), ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        cameraExec.execute {
            try {
                tracker = HandTracker(this, ::onTrackerResult) { msg -> EngineBus.error.value = msg }
            } catch (t: Throwable) {
                EngineBus.error.value = "Hand model missing or failed to load: ${t.message}"
                main.post { shutdown() }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_ACTIVATE -> if (goForeground()) setMode(EngineMode.ACTIVE)
            ACTION_STANDBY -> enterStandbyOrStop()
            ACTION_TOGGLE -> if (EngineBus.mode.value == EngineMode.ACTIVE) shutdown()
                else if (goForeground()) setMode(EngineMode.ACTIVE)
            ACTION_STOP -> shutdown()
            else -> if (!inForeground) shutdown()
        }
        // Never auto-restart: a camera service may not start itself from the background.
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------------ modes

    override fun requestMode(mode: EngineMode) {
        main.post {
            when (mode) {
                EngineMode.ACTIVE -> if (goForeground()) setMode(EngineMode.ACTIVE)
                EngineMode.STANDBY -> enterStandbyOrStop()
                EngineMode.OFF -> shutdown()
            }
        }
    }

    private fun enterStandbyOrStop() {
        val w = repo.config.value.wake
        val wakeWordUsable = w.wakeWordEnabled && hasMic()
        if (!w.wakeGestureEnabled && !wakeWordUsable) { shutdown(); return }
        if (goForeground()) setMode(EngineMode.STANDBY)
    }

    private fun setMode(mode: EngineMode) {
        val previous = EngineBus.mode.value
        EngineBus.mode.value = mode
        val now = SystemClock.uptimeMillis()
        engineExec.execute { engine.setMode(mode, now) }

        val w = repo.config.value.wake
        val needCamera = mode == EngineMode.ACTIVE || (mode == EngineMode.STANDBY && w.wakeGestureEnabled)
        if (needCamera) bindCamera() else unbindCamera()
        applyWakeWord(mode)
        updateNotification(mode)
        if (previous != mode && mode == EngineMode.ACTIVE) haptic(strong = true)
    }

    private fun applyWakeWord(mode: EngineMode) {
        val w = repo.config.value.wake
        val want = mode == EngineMode.STANDBY && w.wakeWordEnabled && hasMic() &&
            (micTypeActive || Build.VERSION.SDK_INT < Build.VERSION_CODES.R)
        if (want && wakeWord == null) {
            wakeWord = WakeWordListener(this) { requestMode(EngineMode.ACTIVE) }.also {
                if (!it.start(w.wakeWord)) wakeWord = null
            }
        } else if (!want) {
            wakeWord?.stop(); wakeWord = null
        }
    }

    private fun shutdown() {
        unbindCamera()
        wakeWord?.stop(); wakeWord = null
        EngineBus.mode.value = EngineMode.OFF
        EngineBus.hand.value = null
        EngineBus.poseLabel.value = null
        engineExec.execute { engine.setMode(EngineMode.OFF, SystemClock.uptimeMillis()) }
        ControlBridge.surface?.setCursorStyle(CursorStyle.HIDDEN)
        if (inForeground) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            inForeground = false
            micTypeActive = false
        }
        stopSelf()
    }

    // ------------------------------------------------------------------ foreground

    private fun goForeground(): Boolean {
        if (!hasCamera()) {
            EngineBus.error.value = "Camera permission is needed. Open AirPoint to grant it."
            shutdown(); return false
        }
        if (inForeground) return true
        var types = 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            types = ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            if (repo.config.value.wake.wakeWordEnabled && hasMic()) {
                types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
        }
        return try {
            ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(EngineMode.ACTIVE), types)
            inForeground = true
            micTypeActive = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
                (types and ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) != 0
            EngineBus.error.value = null
            true
        } catch (t: Throwable) {
            // Android refused (app was in the background). Wake triggers go through
            // WakeTrampolineActivity to avoid this; if we still land here, report it.
            EngineBus.error.value = "Android blocked starting the camera in the background. Open AirPoint once and retry."
            stopSelf()
            false
        }
    }

    private fun buildNotification(mode: EngineMode): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
        )
        val stop = PendingIntent.getService(
            this, 1, intent(this, ACTION_STOP), PendingIntent.FLAG_IMMUTABLE,
        )
        val text = getString(if (mode == EngineMode.STANDBY) R.string.notif_standby else R.string.notif_active)
        return NotificationCompat.Builder(this, AirPointApp.CHANNEL_ENGINE)
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle("AirPoint · Chever3d")
            .setContentText(text)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(open)
            .addAction(0, getString(R.string.notif_stop), stop)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    private fun updateNotification(mode: EngineMode) {
        if (!inForeground) return
        val nm = getSystemService(android.app.NotificationManager::class.java)
        runCatching { nm.notify(NOTIF_ID, buildNotification(mode)) }
    }

    // ------------------------------------------------------------------ camera

    private fun bindCamera() {
        if (cameraBound) return
        cameraBound = true
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            if (!cameraBound) return@addListener
            try {
                val provider = future.get()
                cameraProvider = provider
                val selector = ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                    .setResolutionStrategy(
                        ResolutionStrategy(Size(640, 480), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER),
                    )
                    .build()
                val analysis = ImageAnalysis.Builder()
                    .setResolutionSelector(selector)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(cameraExec) { proxy ->
                    val now = SystemClock.uptimeMillis()
                    val interval = if (EngineBus.mode.value == EngineMode.STANDBY) STANDBY_FRAME_MS else ACTIVE_FRAME_MS
                    val t = tracker
                    if (t == null || now - lastProcessed < interval) { proxy.close(); return@setAnalyzer }
                    lastProcessed = now
                    t.detect(proxy, now)
                }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (t: Throwable) {
                cameraBound = false
                EngineBus.error.value = "Front camera unavailable: ${t.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun unbindCamera() {
        cameraBound = false
        runCatching { cameraProvider?.unbindAll() }
    }

    private fun onTrackerResult(frame: HandFrame?, ts: Long) {
        val now = SystemClock.uptimeMillis()
        fpsCount++
        if (now - fpsWindowStart >= 1000) {
            EngineBus.fps.value = fpsCount * 1000f / (now - fpsWindowStart).coerceAtLeast(1)
            fpsCount = 0; fpsWindowStart = now
        }
        engineExec.execute { engine.onFrame(frame, now) }
    }

    // ------------------------------------------------------------------ misc

    override fun haptic(strong: Boolean) {
        if (!repo.config.value.wake.hapticFeedback) return
        val vib: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION") getSystemService(Vibrator::class.java)
        }
        val effect = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            VibrationEffect.createPredefined(if (strong) VibrationEffect.EFFECT_HEAVY_CLICK else VibrationEffect.EFFECT_TICK)
        } else {
            VibrationEffect.createOneShot(if (strong) 40 else 15, VibrationEffect.DEFAULT_AMPLITUDE)
        }
        runCatching { vib?.vibrate(effect) }
    }

    private fun hasCamera() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onDestroy() {
        runCatching { unregisterReceiver(screenOffReceiver) }
        unbindCamera()
        wakeWord?.stop(); wakeWord = null
        EngineBus.mode.value = EngineMode.OFF
        EngineBus.hand.value = null
        ControlBridge.surface?.setCursorStyle(CursorStyle.HIDDEN)
        cameraExec.execute { tracker?.close(); tracker = null }
        cameraExec.shutdown()
        engineExec.shutdown()
        super.onDestroy()
    }

    companion object {
        const val ACTION_ACTIVATE = "com.chever3d.airpoint.action.ACTIVATE"
        const val ACTION_STANDBY = "com.chever3d.airpoint.action.STANDBY"
        const val ACTION_TOGGLE = "com.chever3d.airpoint.action.TOGGLE"
        const val ACTION_STOP = "com.chever3d.airpoint.action.STOP"

        private const val NOTIF_ID = 42
        private const val ACTIVE_FRAME_MS = 50L   // ~20 fps
        private const val STANDBY_FRAME_MS = 200L // ~5 fps

        fun intent(context: Context, action: String): Intent =
            Intent(context, GestureEngineService::class.java).setAction(action)
    }
}
