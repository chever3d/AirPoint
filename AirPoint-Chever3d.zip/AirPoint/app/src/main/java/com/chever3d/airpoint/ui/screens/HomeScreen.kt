// AirPoint by Chever3d
package com.chever3d.airpoint.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.chever3d.airpoint.data.BuiltInGesture
import com.chever3d.airpoint.engine.EngineMode
import com.chever3d.airpoint.ui.MainViewModel
import com.chever3d.airpoint.ui.components.ApCard
import com.chever3d.airpoint.ui.components.HandSkeleton
import com.chever3d.airpoint.ui.components.Pill
import com.chever3d.airpoint.ui.components.SectionHeader
import com.chever3d.airpoint.ui.components.StatusRing
import com.chever3d.airpoint.ui.theme.ApColors
import com.chever3d.airpoint.util.Permissions

@Composable
fun HomeScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val mode by vm.mode.collectAsState()
    val hand by vm.hand.collectAsState()
    val pose by vm.pose.collectAsState()
    val fps by vm.fps.collectAsState()
    val lastAction by vm.lastAction.collectAsState()
    val error by vm.error.collectAsState()
    val config by vm.config.collectAsState()

    // Re-check permissions whenever we come back from system settings.
    var refresh by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { refresh++ }
    val camOk = remember(refresh) { Permissions.camera(context) }
    val notifOk = remember(refresh) { Permissions.notifications(context) }
    val a11yOk = remember(refresh) { Permissions.accessibilityEnabled(context) }

    val camLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        Spacer(Modifier.height(20.dp))
        Text("AirPoint", style = MaterialTheme.typography.displaySmall)
        Text("by Chever3d", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Spacer(Modifier.height(24.dp))
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            StatusRing(mode = mode, size = 200.dp) {
                if (!camOk) camLauncher.launch(Manifest.permission.CAMERA) else vm.toggleEngine(context)
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (mode != EngineMode.OFF) Pill("${fps.toInt()} fps", ApColors.MutedForeground)
                pose?.let { Pill(it) }
                lastAction?.let { if (mode == EngineMode.ACTIVE) Pill("→ $it", ApColors.Standby) }
            }
        }

        error?.let { msg ->
            Spacer(Modifier.height(16.dp))
            ApCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.ErrorOutline, contentDescription = null, tint = ApColors.Destructive)
                    Spacer(Modifier.width(10.dp))
                    Text(msg, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                }
                TextButton(onClick = vm::clearError, modifier = Modifier.align(Alignment.End)) { Text("Dismiss") }
            }
        }

        if (!camOk || !a11yOk || !notifOk) {
            SectionHeader("Setup")
            ApCard {
                ChecklistRow("Camera", "Sees your hand. Frames never leave the phone.", camOk, "Allow") {
                    camLauncher.launch(Manifest.permission.CAMERA)
                }
                ChecklistRow(
                    "Accessibility service",
                    "Lets AirPoint tap, swipe, go Back/Home and read the volume keys.",
                    a11yOk, "Open",
                ) { Permissions.openAccessibilitySettings(context) }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    ChecklistRow("Notifications", "Shows the on/off control while running.", notifOk, "Allow") {
                        notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            }
        }

        SectionHeader("Live view")
        HandSkeleton(hand)

        SectionHeader("Your gestures")
        ApCard {
            GuideRow(BuiltInGesture.POINT.label, "Move cursor")
            GuideRow(BuiltInGesture.TWO_FINGERS.label, "Scroll")
            GuideRow(BuiltInGesture.FIST.label, "Hold, move, release to drag")
            config.slots.filter { it.enabled }.take(6).forEach { s ->
                val name = BuiltInGesture.fromId(s.gestureId)?.label
                    ?: config.customGestures.firstOrNull { it.id == s.gestureId }?.name ?: "?"
                GuideRow(name, s.action.label)
            }
        }

        Spacer(Modifier.height(24.dp))
        Text(
            "AirPoint 0.1 · made by Chever3d",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.align(Alignment.CenterHorizontally),
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ChecklistRow(title: String, subtitle: String, done: Boolean, cta: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(
            if (done) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
            contentDescription = if (done) "Done" else "Not done",
            tint = if (done) ApColors.Live else ApColors.MutedForeground,
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (!done) {
            Spacer(Modifier.width(8.dp))
            Button(onClick = onClick, modifier = Modifier.heightIn(min = 48.dp)) { Text(cta) }
        }
    }
}

@Composable
private fun GuideRow(gesture: String, action: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(gesture, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
        Text(action, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
