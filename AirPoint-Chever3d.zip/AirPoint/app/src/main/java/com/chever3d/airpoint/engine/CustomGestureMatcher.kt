// AirPoint by Chever3d
package com.chever3d.airpoint.engine

import com.chever3d.airpoint.data.CustomGesture
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Nearest-neighbour matcher for user-recorded poses. Each sample is turned into a
 * 42-float vector that ignores position, size, in-plane rotation and which hand is used.
 */
object CustomGestureMatcher {

    /** Average per-landmark distance (in hand-size units) under which a match is accepted. */
    var threshold = 0.22f

    fun normalise(h: HandFrame): List<Float> {
        val w = h[HandFrame.WRIST]
        val ref = h[HandFrame.MIDDLE_MCP]
        val scale = h.handSize
        // Rotate so wrist -> middle knuckle points straight up.
        val angle = atan2(ref.x - w.x, -(ref.y - w.y))
        val c = cos(-angle); val s = sin(-angle)
        val mirror = if (h.isRightHand) 1f else -1f
        val out = ArrayList<Float>(42)
        for (p in h.points) {
            val dx = (p.x - w.x) / scale
            val dy = (p.y - w.y) / scale
            val rx = dx * c - dy * s
            val ry = dx * s + dy * c
            out += rx * mirror
            out += ry
        }
        return out
    }

    private fun distance(a: List<Float>, b: List<Float>): Float {
        var sum = 0f
        var i = 0
        while (i < a.size) {
            val dx = a[i] - b[i]; val dy = a[i + 1] - b[i + 1]
            sum += sqrt(dx * dx + dy * dy)
            i += 2
        }
        return sum / (a.size / 2)
    }

    /** Returns the id of the closest custom gesture, or null if nothing is close enough. */
    fun match(h: HandFrame, gestures: List<CustomGesture>): String? {
        if (gestures.isEmpty()) return null
        val v = normalise(h)
        var bestId: String? = null
        var best = Float.MAX_VALUE
        for (g in gestures) for (sample in g.samples) {
            if (sample.size != v.size) continue
            val d = distance(v, sample)
            if (d < best) { best = d; bestId = g.id }
        }
        return if (best < threshold) bestId else null
    }
}
