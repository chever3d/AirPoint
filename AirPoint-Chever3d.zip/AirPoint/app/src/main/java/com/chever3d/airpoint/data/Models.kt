// AirPoint by Chever3d
package com.chever3d.airpoint.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Built-in hand gestures. POINT, TWO_FINGERS and FIST are "modes" (cursor, scroll, drag)
 * and are handled by the engine directly; everything with [assignable] = true can be put
 * into a slot and mapped to any [Action].
 */
enum class BuiltInGesture(
    val label: String,
    val hint: String,
    val assignable: Boolean = true,
    val isMotion: Boolean = false,
) {
    POINT("Point", "Index finger up — moves the cursor", assignable = false),
    TWO_FINGERS("Two fingers", "Index + middle up, move up/down — scrolls", assignable = false),
    FIST("Fist", "Close hand and move — drag / long-press drag", assignable = false),
    PINCH("Pinch", "Thumb tip touches index tip"),
    POINT_THUMB("Point + thumb", "Index up with thumb out (L shape)"),
    PINKIE("Pinkie", "Only little finger up"),
    PALM("Open palm", "All five fingers spread, held still"),
    THREE("Three fingers", "Index, middle and ring up"),
    ROCK("Rock", "Index + pinkie up (horns)"),
    OK("OK sign", "Thumb and index circle, other fingers up"),
    THUMBS_UP("Thumbs up", "Fist with thumb pointing up"),
    THUMBS_DOWN("Thumbs down", "Fist with thumb pointing down"),
    SWIPE_LEFT("Swipe left", "Open palm moved quickly to your left", isMotion = true),
    SWIPE_RIGHT("Swipe right", "Open palm moved quickly to your right", isMotion = true);

    val id: String get() = "builtin:$name"

    companion object {
        fun fromId(id: String): BuiltInGesture? =
            if (id.startsWith("builtin:")) entries.firstOrNull { it.name == id.removePrefix("builtin:") } else null
    }
}

/** Everything a gesture slot can trigger. */
@Serializable
sealed interface Action {
    val label: String

    @Serializable @SerialName("none") data object None : Action { override val label get() = "Do nothing" }
    @Serializable @SerialName("tap") data object Tap : Action { override val label get() = "Tap at cursor" }
    @Serializable @SerialName("double_tap") data object DoubleTap : Action { override val label get() = "Double tap" }
    @Serializable @SerialName("long_press") data object LongPress : Action { override val label get() = "Long press" }
    @Serializable @SerialName("back") data object Back : Action { override val label get() = "Back" }
    @Serializable @SerialName("home") data object Home : Action { override val label get() = "Home" }
    @Serializable @SerialName("recents") data object Recents : Action { override val label get() = "Recent apps" }
    @Serializable @SerialName("notifications") data object Notifications : Action { override val label get() = "Notifications" }
    @Serializable @SerialName("quick_settings") data object QuickSettings : Action { override val label get() = "Quick settings" }
    @Serializable @SerialName("screenshot") data object Screenshot : Action { override val label get() = "Screenshot" }
    @Serializable @SerialName("lock") data object LockScreen : Action { override val label get() = "Lock screen" }
    @Serializable @SerialName("power_menu") data object PowerMenu : Action { override val label get() = "Power menu" }
    @Serializable @SerialName("swipe_up") data object SwipeUp : Action { override val label get() = "Swipe up" }
    @Serializable @SerialName("swipe_down") data object SwipeDown : Action { override val label get() = "Swipe down" }
    @Serializable @SerialName("swipe_left") data object SwipeLeft : Action { override val label get() = "Swipe left" }
    @Serializable @SerialName("swipe_right") data object SwipeRight : Action { override val label get() = "Swipe right" }
    @Serializable @SerialName("volume_up") data object VolumeUp : Action { override val label get() = "Volume up" }
    @Serializable @SerialName("volume_down") data object VolumeDown : Action { override val label get() = "Volume down" }
    @Serializable @SerialName("mute") data object Mute : Action { override val label get() = "Mute / unmute" }
    @Serializable @SerialName("play_pause") data object PlayPause : Action { override val label get() = "Play / pause" }
    @Serializable @SerialName("next_track") data object NextTrack : Action { override val label get() = "Next track" }
    @Serializable @SerialName("prev_track") data object PrevTrack : Action { override val label get() = "Previous track" }
    @Serializable @SerialName("flashlight") data object Flashlight : Action { override val label get() = "Flashlight" }
    @Serializable @SerialName("recenter") data object RecenterCursor : Action { override val label get() = "Re-centre cursor" }
    @Serializable @SerialName("sleep") data object Sleep : Action { override val label get() = "Pause gestures (standby)" }
    @Serializable @SerialName("turn_off") data object TurnOff : Action { override val label get() = "Turn gestures off" }

    @Serializable @SerialName("open_app")
    data class OpenApp(val packageName: String, val appLabel: String) : Action {
        override val label get() = "Open $appLabel"
    }

    companion object {
        /** Simple actions shown in the picker, grouped. OpenApp is added separately. */
        val groups: List<Pair<String, List<Action>>> = listOf(
            "Touch" to listOf(Tap, DoubleTap, LongPress, SwipeUp, SwipeDown, SwipeLeft, SwipeRight),
            "System" to listOf(Back, Home, Recents, Notifications, QuickSettings, Screenshot, LockScreen, PowerMenu),
            "Media & device" to listOf(VolumeUp, VolumeDown, Mute, PlayPause, NextTrack, PrevTrack, Flashlight),
            "AirPoint" to listOf(RecenterCursor, Sleep, TurnOff, None),
        )
    }
}

@Serializable
data class Slot(
    val id: String,
    val gestureId: String,
    val action: Action,
    /** How long the pose must be held before it fires. 0 = as soon as it is recognised. */
    val holdMs: Int = 250,
    /** Keep firing while held (good for volume). */
    val repeat: Boolean = false,
    val repeatEveryMs: Int = 350,
    val enabled: Boolean = true,
    /** Per-app profile: only active while this app is in front. null = everywhere. */
    val appPackage: String? = null,
    val appLabel: String? = null,
)

@Serializable
data class CustomGesture(
    val id: String,
    val name: String,
    /** Each sample is a normalised 42-float vector (21 landmarks × x,y). */
    val samples: List<List<Float>>,
)

@Serializable
enum class CursorMode { RELATIVE, ABSOLUTE }

@Serializable
data class CursorSettings(
    val mode: CursorMode = CursorMode.RELATIVE,
    /** Screen widths travelled per full frame width of hand movement (relative mode). */
    val sensitivity: Float = 2.2f,
    /** Extra speed for fast hand movements. 0 = linear. */
    val acceleration: Float = 0.6f,
    /** One-Euro min cutoff: lower = smoother but laggier. */
    val smoothing: Float = 1.2f,
    /** Fraction of the camera frame used as the "touchpad" in absolute mode. */
    val activeArea: Float = 0.6f,
    val cursorSizeDp: Int = 22,
)

@Serializable
data class WakeSettings(
    /** Hold Volume Down ~0.6 s to toggle gestures (screen on). */
    val volumeDownHold: Boolean = true,
    /** Press Volume Up + Down together to toggle gestures. */
    val volumeCombo: Boolean = false,
    /** Any learned key code (Bluetooth clicker, headset button, remapped key). -1 = none. */
    val learnedKeyCode: Int = -1,
    val learnedKeyName: String = "",
    /** Start gestures straight away when the accessibility shortcut turns the service on. */
    val startOnShortcut: Boolean = true,
    val wakeGestureEnabled: Boolean = false,
    val wakeGestureId: String = BuiltInGesture.ROCK.id,
    val wakeGestureHoldMs: Int = 1200,
    val wakeWordEnabled: Boolean = false,
    /** Porcupine built-in keyword name, or "custom" to use assets/wake/custom_wake_word.ppn. */
    val wakeWord: String = "JARVIS",
    /** Seconds without a hand before going to standby (or off). */
    val idleSleepSec: Int = 20,
    val hapticFeedback: Boolean = true,
)

@Serializable
data class AppConfig(
    val slots: List<Slot> = DefaultConfig.slots,
    val customGestures: List<CustomGesture> = emptyList(),
    val cursor: CursorSettings = CursorSettings(),
    val wake: WakeSettings = WakeSettings(),
    val onboardingSeen: Boolean = false,
)

object DefaultConfig {
    val slots: List<Slot> = listOf(
        Slot("s_pinch", BuiltInGesture.PINCH.id, Action.Tap, holdMs = 0),
        Slot("s_lthumb", BuiltInGesture.POINT_THUMB.id, Action.Tap, holdMs = 0),
        Slot("s_pinkie", BuiltInGesture.PINKIE.id, Action.Back, holdMs = 250),
        Slot("s_palm", BuiltInGesture.PALM.id, Action.Home, holdMs = 600),
        Slot("s_swl", BuiltInGesture.SWIPE_LEFT.id, Action.Recents, holdMs = 0),
        Slot("s_swr", BuiltInGesture.SWIPE_RIGHT.id, Action.Notifications, holdMs = 0),
        Slot("s_three", BuiltInGesture.THREE.id, Action.QuickSettings, holdMs = 400),
        Slot("s_tup", BuiltInGesture.THUMBS_UP.id, Action.VolumeUp, holdMs = 300, repeat = true),
        Slot("s_tdown", BuiltInGesture.THUMBS_DOWN.id, Action.VolumeDown, holdMs = 300, repeat = true),
        Slot("s_ok", BuiltInGesture.OK.id, Action.Screenshot, holdMs = 700),
        Slot("s_rock", BuiltInGesture.ROCK.id, Action.Sleep, holdMs = 1000),
    )

    /** Porcupine's free built-in keywords. */
    val wakeWords = listOf(
        "JARVIS", "COMPUTER", "PORCUPINE", "BUMBLEBEE", "TERMINATOR", "PICOVOICE",
        "GRASSHOPPER", "BLUEBERRY", "AMERICANO", "custom",
    )
}
