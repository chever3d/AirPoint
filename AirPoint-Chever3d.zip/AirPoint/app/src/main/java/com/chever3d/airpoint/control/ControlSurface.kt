// AirPoint by Chever3d
package com.chever3d.airpoint.control

import com.chever3d.airpoint.data.Action

enum class CursorStyle { HIDDEN, POINTER, PRESS, SCROLL, DRAG, LOST }

/**
 * What the gesture engine can do to the screen. Implemented by the accessibility service,
 * which is the only component Android allows to inject taps and system actions.
 * Distances are in units of screen WIDTH on both axes so movement is isotropic.
 */
interface ControlSurface {
    val foregroundPackage: String?
    fun moveCursorBy(dx: Float, dy: Float)
    /** Absolute position, 0..1 of screen width / height. */
    fun setCursorAt(xFrac: Float, yFrac: Float)
    fun recenterCursor()
    fun setCursorStyle(style: CursorStyle)
    fun perform(action: Action)
    /** Positive = hand moved down = finger-drag downward. */
    fun scrollBy(dy: Float)
    fun dragStart()
    fun dragEnd()
}

/** Holds the live accessibility service, or null when it is not enabled. */
object ControlBridge {
    @Volatile var surface: ControlSurface? = null
}
