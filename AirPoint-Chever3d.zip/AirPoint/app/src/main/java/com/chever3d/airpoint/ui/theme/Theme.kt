// AirPoint by Chever3d
// Design system from ui-ux-pro-max: "Dark Mode (OLED)" style,
// JetBrains Mono headings + IBM Plex Sans body, green = live.
package com.chever3d.airpoint.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.chever3d.airpoint.R

// ---- Colour tokens -------------------------------------------------------------
object ApColors {
    val Background = Color(0xFF0F172A)
    val Card = Color(0xFF1B2336)
    val Muted = Color(0xFF272F42)
    val Border = Color(0xFF475569)
    val Primary = Color(0xFF1E293B)
    val Secondary = Color(0xFF334155)
    val Foreground = Color(0xFFF8FAFC)
    val MutedForeground = Color(0xFF94A3B8)
    val Live = Color(0xFF22C55E)       // accent / "gestures on"
    val OnLive = Color(0xFF0F172A)
    val Standby = Color(0xFFF59E0B)    // amber = waiting for wake
    val Destructive = Color(0xFFEF4444)
}

private val scheme = darkColorScheme(
    primary = ApColors.Live,
    onPrimary = ApColors.OnLive,
    primaryContainer = ApColors.Secondary,
    onPrimaryContainer = ApColors.Foreground,
    secondary = ApColors.Secondary,
    onSecondary = ApColors.Foreground,
    secondaryContainer = ApColors.Muted,
    onSecondaryContainer = ApColors.Foreground,
    tertiary = ApColors.Standby,
    background = ApColors.Background,
    onBackground = ApColors.Foreground,
    surface = ApColors.Background,
    onSurface = ApColors.Foreground,
    surfaceVariant = ApColors.Muted,
    onSurfaceVariant = ApColors.MutedForeground,
    surfaceContainer = ApColors.Card,
    surfaceContainerLow = ApColors.Card,
    surfaceContainerHigh = ApColors.Muted,
    surfaceContainerHighest = ApColors.Secondary,
    outline = ApColors.Border,
    outlineVariant = ApColors.Muted,
    error = ApColors.Destructive,
    onError = Color.Black,
)

// ---- Type ----------------------------------------------------------------------
@OptIn(ExperimentalTextApi::class)
private fun mono(weight: FontWeight) = Font(
    R.font.jetbrains_mono, weight, variationSettings = FontVariation.Settings(FontVariation.weight(weight.weight)),
)

@OptIn(ExperimentalTextApi::class)
private fun plex(weight: FontWeight) = Font(
    R.font.ibm_plex_sans, weight, variationSettings = FontVariation.Settings(FontVariation.weight(weight.weight)),
)

val Mono = FontFamily(mono(FontWeight.Normal), mono(FontWeight.Medium), mono(FontWeight.SemiBold), mono(FontWeight.Bold))
val Plex = FontFamily(plex(FontWeight.Normal), plex(FontWeight.Medium), plex(FontWeight.SemiBold), plex(FontWeight.Bold))

private val typography = Typography(
    displaySmall = TextStyle(fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 38.sp),
    headlineMedium = TextStyle(fontFamily = Mono, fontWeight = FontWeight.SemiBold, fontSize = 24.sp, lineHeight = 30.sp),
    headlineSmall = TextStyle(fontFamily = Mono, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp),
    titleLarge = TextStyle(fontFamily = Mono, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontFamily = Mono, fontWeight = FontWeight.Medium, fontSize = 16.sp, lineHeight = 22.sp),
    titleSmall = TextStyle(fontFamily = Mono, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontFamily = Plex, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = Plex, fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontFamily = Plex, fontSize = 12.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontFamily = Plex, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),
    labelMedium = TextStyle(fontFamily = Plex, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp),
    labelSmall = TextStyle(fontFamily = Mono, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 16.sp),
)

@Composable
fun AirPointTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = typography, content = content)
}
