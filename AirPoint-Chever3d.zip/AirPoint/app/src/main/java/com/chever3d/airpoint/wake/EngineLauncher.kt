// AirPoint by Chever3d
package com.chever3d.airpoint.wake

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.chever3d.airpoint.engine.EngineBus
import com.chever3d.airpoint.engine.EngineMode
import com.chever3d.airpoint.engine.GestureEngineService

/**
 * One place that knows how to start / stop the engine legally from anywhere.
 *
 * Android only lets a camera service start while the app is visible. So when the engine is
 * OFF and the request comes from the background (volume key, tile, shortcut), we bounce
 * through an invisible [WakeTrampolineActivity] that starts the service from the foreground.
 */
object EngineLauncher {

    fun activate(context: Context) = send(context, GestureEngineService.ACTION_ACTIVATE)

    fun stop(context: Context) {
        if (EngineBus.mode.value == EngineMode.OFF) return
        runCatching { context.startService(GestureEngineService.intent(context, GestureEngineService.ACTION_STOP)) }
    }

    /** ACTIVE -> off, STANDBY/OFF -> active. */
    fun toggle(context: Context) {
        if (EngineBus.mode.value == EngineMode.ACTIVE) stop(context) else activate(context)
    }

    private fun send(context: Context, action: String) {
        val intent = GestureEngineService.intent(context, action)
        when {
            // Service already in the foreground: the app counts as foreground, plain start is fine.
            EngineBus.mode.value != EngineMode.OFF -> runCatching { context.startService(intent) }
            // Called from our own visible screen.
            context is Activity -> ContextCompat.startForegroundService(context, intent)
            else -> context.startActivity(trampolineIntent(context, action))
        }
    }

    fun trampolineIntent(context: Context, action: String): Intent =
        Intent(context, WakeTrampolineActivity::class.java)
            .putExtra(WakeTrampolineActivity.EXTRA_ACTION, action)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
}
