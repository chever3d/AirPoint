// AirPoint by Chever3d
package com.chever3d.airpoint.control

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import android.view.animation.DecelerateInterpolator

/**
 * Full-screen, non-touchable overlay that draws the AirPoint cursor.
 * Green ring = pointing, filled = pressing, chevrons = scrolling, white = dragging.
 */
class CursorOverlayView(context: Context) : View(context) {

    private val density = resources.displayMetrics.density
    var radiusPx = 11f * density
        set(value) { field = value; invalidate() }

    private var cx = -1000f
    private var cy = -1000f
    var style: CursorStyle = CursorStyle.HIDDEN
        set(value) { if (field != value) { field = value; invalidate() } }

    private var ripple = 0f // 0..1

    private val accent = Color.parseColor("#22C55E")
    private val ink = Color.parseColor("#F8FAFC")
    private val shadow = Color.parseColor("#990F172A")

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f * density; color = accent
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = accent }
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 6f * density; color = shadow
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = ink }
    private val ripplePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f * density; color = accent
    }
    private val chevron = Path()

    fun moveTo(x: Float, y: Float) {
        cx = x; cy = y
        invalidate()
    }

    /** Short expanding ring when an action fires. Skipped automatically if animations are off. */
    fun pulse() {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener { ripple = it.animatedValue as Float; invalidate() }
            doOnEndCompat { ripple = 0f; invalidate() }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        if (style == CursorStyle.HIDDEN) return
        val r = radiusPx
        val alpha = if (style == CursorStyle.LOST) 90 else 255
        ring.alpha = alpha; dot.alpha = alpha; halo.alpha = (alpha * 0.6f).toInt()

        canvas.drawCircle(cx, cy, r, halo)
        when (style) {
            CursorStyle.PRESS -> { fill.color = accent; canvas.drawCircle(cx, cy, r * 0.85f, fill) }
            CursorStyle.DRAG -> { fill.color = ink; canvas.drawCircle(cx, cy, r * 0.85f, fill) }
            else -> canvas.drawCircle(cx, cy, r, ring)
        }
        canvas.drawCircle(cx, cy, 2.5f * density, dot)

        if (style == CursorStyle.SCROLL) {
            val o = r * 1.7f; val w = r * 0.6f
            chevron.reset()
            chevron.moveTo(cx - w, cy - o + w); chevron.lineTo(cx, cy - o); chevron.lineTo(cx + w, cy - o + w)
            chevron.moveTo(cx - w, cy + o - w); chevron.lineTo(cx, cy + o); chevron.lineTo(cx + w, cy + o - w)
            canvas.drawPath(chevron, ring)
        }
        if (ripple > 0f) {
            ripplePaint.alpha = ((1f - ripple) * 255).toInt()
            canvas.drawCircle(cx, cy, r * (1f + ripple * 1.6f), ripplePaint)
        }
    }

    private inline fun ValueAnimator.doOnEndCompat(crossinline block: () -> Unit) {
        addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) = block()
        })
    }
}
