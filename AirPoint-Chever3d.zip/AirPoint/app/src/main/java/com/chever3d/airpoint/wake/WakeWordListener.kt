// AirPoint by Chever3d
package com.chever3d.airpoint.wake

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.content.Context
import com.chever3d.airpoint.BuildConfig
import com.chever3d.airpoint.engine.EngineBus

/**
 * Offline wake word using Picovoice Porcupine (runs on the CPU, not the low-power DSP chip that
 * "OK Google" uses, so it costs a little battery; it only runs while AirPoint is in standby).
 *
 * Setup: get a free AccessKey at console.picovoice.ai and add
 *   picovoice.accessKey=YOUR_KEY
 * to local.properties. For a custom phrase like "Hey Chever", train it on the console
 * (platform: Android) and save it as app/src/main/assets/wake/custom_wake_word.ppn.
 */
class WakeWordListener(
    private val context: Context,
    private val onWake: () -> Unit,
) {
    private var manager: PorcupineManager? = null

    fun start(keyword: String): Boolean {
        val key = BuildConfig.PICOVOICE_ACCESS_KEY
        if (key.isBlank()) {
            EngineBus.error.value = "Wake word needs a Picovoice AccessKey in local.properties."
            EngineBus.wakeWordReady.value = false
            return false
        }
        return try {
            val builder = PorcupineManager.Builder()
                .setAccessKey(key)
                .setSensitivity(0.6f)
            if (keyword == "custom") {
                builder.setKeywordPath(CUSTOM_PATH)
            } else {
                builder.setKeyword(Porcupine.BuiltInKeyword.valueOf(keyword))
            }
            manager = builder.build(context, PorcupineManagerCallback { onWake() })
            manager?.start()
            EngineBus.wakeWordReady.value = true
            true
        } catch (t: Throwable) {
            EngineBus.error.value = "Wake word failed: ${t.message}"
            EngineBus.wakeWordReady.value = false
            manager = null
            false
        }
    }

    fun stop() {
        runCatching { manager?.stop() }
        runCatching { manager?.delete() }
        manager = null
        EngineBus.wakeWordReady.value = false
    }

    companion object {
        const val CUSTOM_PATH = "wake/custom_wake_word.ppn"
    }
}
