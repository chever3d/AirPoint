// AirPoint by Chever3d
package com.chever3d.airpoint.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.chever3d.airpoint.BuildConfig
import com.chever3d.airpoint.data.BuiltInGesture
import com.chever3d.airpoint.data.DefaultConfig
import com.chever3d.airpoint.ui.MainViewModel
import com.chever3d.airpoint.ui.components.ApCard
import com.chever3d.airpoint.ui.components.ChoiceButton
import com.chever3d.airpoint.ui.components.SectionHeader
import com.chever3d.airpoint.ui.components.SliderRow
import com.chever3d.airpoint.ui.components.SwitchRow
import com.chever3d.airpoint.ui.theme.ApColors
import com.chever3d.airpoint.util.Permissions

@Composable
fun WakeScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val config by vm.config.collectAsState()
    val learning by vm.learningKey.collectAsState()
    val w = config.wake

    var refresh by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { refresh++ }
    val a11yOk = remember(refresh) { Permissions.accessibilityEnabled(context) }
    val micOk = remember(refresh) { Permissions.mic(context) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        refresh++
        if (granted) vm.updateWake { it.copy(wakeWordEnabled = true) }
    }
    // Leave learn mode if the user navigates away.
    DisposableEffect(Unit) { onDispose { vm.cancelLearningKey() } }

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        Spacer(Modifier.height(20.dp))
        Text("Wake & toggle", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Ways to turn gesture control on and off. Buttons cost no battery.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        if (!a11yOk) {
            Spacer(Modifier.height(12.dp))
            ApCard {
                Text("Button triggers need the AirPoint accessibility service.", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { Permissions.openAccessibilitySettings(context) }, modifier = Modifier.heightIn(min = 48.dp)) {
                    Text("Turn it on")
                }
            }
        }

        SectionHeader("Buttons")
        ApCard {
            Text("Hold both volume keys · 3 s", style = MaterialTheme.typography.titleSmall)
            Text(
                "Android's own Accessibility shortcut. Set AirPoint as the shortcut target: it works from anywhere, even the lock screen. Same hold turns it off.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { Permissions.openAccessibilitySettings(context) }, modifier = Modifier.heightIn(min = 48.dp)) {
                Text("Set up shortcut")
            }
            SwitchRow("Start gestures when switched on", "Begin tracking right after the shortcut.", w.startOnShortcut) {
                vm.updateWake { s -> s.copy(startOnShortcut = it) }
            }
            HorizontalDivider(color = ApColors.Muted)
            SwitchRow("Hold Volume Down", "Hold ~0.6 s to toggle. A short press still lowers volume.", w.volumeDownHold) {
                vm.updateWake { s -> s.copy(volumeDownHold = it) }
            }
            HorizontalDivider(color = ApColors.Muted)
            SwitchRow("Press Volume Up + Down together", "Quick squeeze of both keys toggles.", w.volumeCombo) {
                vm.updateWake { s -> s.copy(volumeCombo = it) }
            }
            HorizontalDivider(color = ApColors.Muted)
            Column(Modifier.padding(vertical = 8.dp)) {
                Text("Dedicated button", style = MaterialTheme.typography.bodyLarge)
                Text(
                    when {
                        learning -> "Press the button now…"
                        w.learnedKeyCode != -1 -> "Using: ${w.learnedKeyName}"
                        else -> "A Bluetooth selfie clicker, headset button or remapped key. Works if Android passes the key to apps."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (learning) ApColors.Live else MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { if (learning) vm.cancelLearningKey() else vm.startLearningKey() },
                        enabled = a11yOk,
                        modifier = Modifier.heightIn(min = 48.dp),
                    ) { Text(if (learning) "Cancel" else "Learn button") }
                    if (w.learnedKeyCode != -1) {
                        OutlinedButton(onClick = vm::clearLearnedKey, modifier = Modifier.heightIn(min = 48.dp)) { Text("Clear") }
                    }
                }
            }
            HorizontalDivider(color = ApColors.Muted)
            Text(
                "Quick Settings tile: pull down, edit tiles, add \"Gestures\".",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 10.dp),
            )
        }

        SectionHeader("Hands-free (uses battery)")
        ApCard {
            SwitchRow(
                "Wake gesture",
                "After auto-standby, the camera checks 5× a second for this pose.",
                w.wakeGestureEnabled,
            ) { vm.updateWake { s -> s.copy(wakeGestureEnabled = it) } }
            if (w.wakeGestureEnabled) {
                val options = BuiltInGesture.entries.filter { it.assignable && !it.isMotion }.map { it.id } +
                    config.customGestures.map { it.id }
                ChoiceButton(
                    label = BuiltInGesture.fromId(w.wakeGestureId)?.label
                        ?: config.customGestures.firstOrNull { it.id == w.wakeGestureId }?.name ?: "Choose",
                    options = options,
                    optionLabel = { id ->
                        BuiltInGesture.fromId(id)?.label ?: config.customGestures.firstOrNull { it.id == id }?.name ?: id
                    },
                    onPick = { id -> vm.updateWake { it.copy(wakeGestureId = id) } },
                )
                SliderRow(
                    "Hold for", "%.1f s".format(w.wakeGestureHoldMs / 1000f),
                    w.wakeGestureHoldMs.toFloat(), 500f..3000f, steps = 24,
                ) { v -> vm.updateWake { it.copy(wakeGestureHoldMs = (v / 100).toInt() * 100) } }
            }
            HorizontalDivider(color = ApColors.Muted)
            SwitchRow(
                "Wake word",
                if (BuildConfig.PICOVOICE_ACCESS_KEY.isBlank()) "Needs a free Picovoice key in local.properties (see README)."
                else "Listens offline during standby. Shows the mic indicator.",
                w.wakeWordEnabled,
            ) { on ->
                if (on && !micOk) micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                else vm.updateWake { it.copy(wakeWordEnabled = on) }
            }
            if (w.wakeWordEnabled) {
                ChoiceButton(
                    label = if (w.wakeWord == "custom") "Custom (.ppn file)" else w.wakeWord.lowercase().replaceFirstChar { it.uppercase() },
                    options = DefaultConfig.wakeWords,
                    optionLabel = { if (it == "custom") "Custom (.ppn file)" else it.lowercase().replaceFirstChar { c -> c.uppercase() } },
                    onPick = { word -> vm.updateWake { it.copy(wakeWord = word) } },
                    modifier = Modifier.padding(bottom = 8.dp),
                )
            }
        }

        SectionHeader("Auto standby")
        ApCard {
            SliderRow(
                "No hand for", "${w.idleSleepSec} s", w.idleSleepSec.toFloat(), 5f..120f, steps = 22,
                hint = "Then goes to standby, or fully off if no hands-free wake is on.",
            ) { v -> vm.updateWake { it.copy(idleSleepSec = v.toInt()) } }
            SwitchRow("Haptic feedback", "Buzz on wake and on drag start.", w.hapticFeedback) {
                vm.updateWake { s -> s.copy(hapticFeedback = it) }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
