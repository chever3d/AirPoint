// AirPoint by Chever3d
package com.chever3d.airpoint.wake

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.chever3d.airpoint.engine.EngineBus
import com.chever3d.airpoint.engine.EngineMode
import com.chever3d.airpoint.engine.GestureEngineService
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Invisible, instant activity. Being on screen for a split second lets us start the camera
 * foreground service legally after a background trigger. Closes as soon as the service is up.
 */
class WakeTrampolineActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) setShowWhenLocked(true)

        val action = intent.getStringExtra(EXTRA_ACTION) ?: GestureEngineService.ACTION_ACTIVATE
        runCatching {
            ContextCompat.startForegroundService(this, GestureEngineService.intent(this, action))
        }
        lifecycleScope.launch {
            // Stay visible until the service is in the foreground (max 1.5 s).
            withTimeoutOrNull(1500) { EngineBus.mode.first { it != EngineMode.OFF } }
            finish()
            @Suppress("DEPRECATION") overridePendingTransition(0, 0)
        }
    }

    companion object {
        const val EXTRA_ACTION = "action"
    }
}
