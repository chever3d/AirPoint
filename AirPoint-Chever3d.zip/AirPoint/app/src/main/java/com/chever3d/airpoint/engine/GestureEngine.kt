// AirPoint by Chever3d
package com.chever3d.airpoint.engine

import com.chever3d.airpoint.control.ControlBridge
import com.chever3d.airpoint.control.CursorStyle
import com.chever3d.airpoint.data.Action
import com.chever3d.airpoint.data.AppConfig
import com.chever3d.airpoint.data.BuiltInGesture
import com.chever3d.airpoint.data.CursorMode
import com.chever3d.airpoint.data.Slot
import kotlin.math.abs
import kotlin.math.hypot

/** What the engine needs from the service that owns it. */
interface EngineHost {
    fun requestMode(mode: EngineMode)
    fun haptic(strong: Boolean)
}

/**
 * Turns a stream of hand frames into cursor movement, scrolling, dragging and slot actions.
 * Pure logic, no Android camera code, so it is easy to tune and test.
 *
 * Modes (fixed):   POINT = move cursor · TWO_FINGERS = scroll · FIST (held) = drag
 * Slots (custom):  any other built-in or recorded gesture -> any Action
 */
class GestureEngine(private val host: EngineHost) {

    @Volatile var config: AppConfig = AppConfig()
    @Volatile var mode: EngineMode = EngineMode.ACTIVE
        private set

    // --- smoothing / cursor ---
    private val fx = OneEuroFilter()
    private val fy = OneEuroFilter()
    private var lastAnchorX = Float.NaN
    private var lastAnchorY = 0f
    private var lastAnchorT = 0L
    private var freezeUntil = 0L

    // --- pose stabilisation ---
    private var candidate: String? = null
    private var candidateFrames = 0
    private var stable: String? = null
    private var stableSince = 0L
    private var stableX = 0f
    private var stableY = 0f
    private var firedForStable = false
    private var lastFireAt = 0L
    private var lastAnyFireAt = 0L

    // --- scroll / drag / swipe ---
    private var scrollAccum = 0f
    private var lastScrollEmit = 0L
    private var lastScrollY = Float.NaN
    private var dragging = false
    private val palmTrail = ArrayDeque<Triple<Long, Float, Float>>()
    private var swipeCooldownUntil = 0L

    // --- presence ---
    private var lastHandSeen = 0L
    private var cursorStyle = CursorStyle.HIDDEN

    fun setMode(newMode: EngineMode, now: Long) {
        if (newMode == mode) return
        endDrag()
        mode = newMode
        // The pose that woke us (e.g. a held 🤘) must be released before it can fire again.
        // Keep the current stable pose so it is not re-recognised as a fresh gesture.
        firedForStable = true
        lastHandSeen = now
        clutch()
        palmTrail.clear()
        style(if (newMode == EngineMode.ACTIVE) CursorStyle.POINTER else CursorStyle.HIDDEN)
    }

    fun onFrame(h: HandFrame?, now: Long) {
        EngineBus.hand.value = h
        if (h == null) { onNoHand(now); return }
        lastHandSeen = now

        val cfg = config
        val builtIn = PoseClassifier.classify(h)
        val customId = CustomGestureMatcher.match(h, cfg.customGestures)
        val raw: String? = customId ?: builtIn?.id
        EngineBus.poseLabel.value = labelFor(raw, cfg)

        updateStable(raw, h, now)

        when (mode) {
            EngineMode.STANDBY -> handleStandby(now)
            EngineMode.ACTIVE -> if (!EngineBus.suppressActions.value) handleActive(h, builtIn, now)
            EngineMode.OFF -> Unit
        }
    }

    // ------------------------------------------------------------------ standby

    private fun handleStandby(now: Long) {
        val w = config.wake
        if (!w.wakeGestureEnabled) return
        if (stable == w.wakeGestureId && !firedForStable && now - stableSince >= w.wakeGestureHoldMs) {
            firedForStable = true
            host.haptic(strong = true)
            host.requestMode(EngineMode.ACTIVE)
        }
    }

    // ------------------------------------------------------------------ active

    private fun handleActive(h: HandFrame, builtIn: BuiltInGesture?, now: Long) {
        val surface = ControlBridge.surface
        val st = BuiltInGesture.fromId(stable ?: "")

        // 1) Swipes (open palm moved fast sideways). Checked on the raw pose for responsiveness.
        if (builtIn == BuiltInGesture.PALM) {
            val c = h[HandFrame.WRIST].mid(h[HandFrame.MIDDLE_MCP])
            if (detectSwipe(c.x, c.y, now)) return
        } else palmTrail.clear()

        // 2) Continuous modes.
        when (st) {
            BuiltInGesture.POINT, BuiltInGesture.POINT_THUMB, BuiltInGesture.PINCH -> {
                // Only track while this frame still shows a cursor pose (avoids jumps mid-transition).
                if (builtIn in CURSOR_POSES) moveCursor(h, now) else clutch()
                lastScrollY = Float.NaN
                style(if (st == BuiltInGesture.POINT) CursorStyle.POINTER else CursorStyle.PRESS)
            }
            BuiltInGesture.TWO_FINGERS -> {
                if (builtIn == BuiltInGesture.TWO_FINGERS) scroll(h, now) else lastScrollY = Float.NaN
                clutch()
                style(CursorStyle.SCROLL)
            }
            BuiltInGesture.FIST -> {
                if (!dragging && now - stableSince > FIST_DRAG_DELAY_MS) {
                    dragging = true
                    surface?.dragStart()
                    host.haptic(strong = false)
                }
                if (dragging) {
                    if (builtIn == BuiltInGesture.FIST) moveCursor(h, now) else clutch()
                    style(CursorStyle.DRAG)
                }
            }
            else -> { clutch(); lastScrollY = Float.NaN; style(CursorStyle.POINTER) }
        }

        // 3) Discrete slot gestures.
        val id = stable ?: return
        if (st != null && !st.assignable) return
        val slot = findSlot(id, surface?.foregroundPackage) ?: return
        val held = now - stableSince
        if (now - lastAnyFireAt < GLOBAL_COOLDOWN_MS) return
        if (!firedForStable && held >= slot.holdMs) {
            fire(slot.action, now); firedForStable = true; lastFireAt = now
        } else if (firedForStable && slot.repeat && now - lastFireAt >= slot.repeatEveryMs) {
            fire(slot.action, now); lastFireAt = now
        }
    }

    private fun moveCursor(h: HandFrame, now: Long) {
        val surface = ControlBridge.surface ?: return
        val cur = config.cursor
        // Anchor mostly on the index knuckle: it barely moves when you pinch, so clicks don't jump.
        val knuckle = h[HandFrame.INDEX_MCP]
        val tip = h[HandFrame.INDEX_TIP]
        val ax0 = knuckle.x * 0.7f + tip.x * 0.3f
        val ay0 = knuckle.y * 0.7f + tip.y * 0.3f
        fx.minCutoff = cur.smoothing; fy.minCutoff = cur.smoothing
        val ax = fx.filter(ax0, now)
        val ay = fy.filter(ay0, now)

        if (cur.mode == CursorMode.ABSOLUTE) {
            val area = cur.activeArea.coerceIn(0.2f, 1f)
            val m = (1f - area) / 2f
            val ux = ((ax - m) / area).coerceIn(0f, 1f)
            val uy = ((ay / h.aspect - m) / area).coerceIn(0f, 1f)
            if (now >= freezeUntil) surface.setCursorAt(ux, uy)
        } else if (!lastAnchorX.isNaN() && now >= freezeUntil) {
            val dx = ax - lastAnchorX
            val dy = ay - lastAnchorY
            val dt = ((now - lastAnchorT).coerceAtLeast(1)) / 1000f
            val speed = hypot(dx, dy) / dt // image widths per second
            val gain = cur.sensitivity * (1f + cur.acceleration * speed)
            surface.moveCursorBy(dx * gain, dy * gain)
        }
        lastAnchorX = ax; lastAnchorY = ay; lastAnchorT = now
    }

    /** Hand moved without a cursor pose: like lifting a mouse, the cursor stays put. */
    private fun clutch() {
        lastAnchorX = Float.NaN
        fx.reset(); fy.reset()
    }

    private fun scroll(h: HandFrame, now: Long) {
        val y = h[HandFrame.INDEX_TIP].mid(h[HandFrame.MIDDLE_TIP]).y
        if (!lastScrollY.isNaN()) scrollAccum += (y - lastScrollY)
        lastScrollY = y
        if (now - lastScrollEmit >= SCROLL_EMIT_MS && abs(scrollAccum) > SCROLL_DEADZONE) {
            ControlBridge.surface?.scrollBy(scrollAccum * config.cursor.sensitivity)
            scrollAccum = 0f
            lastScrollEmit = now
        }
    }

    private fun detectSwipe(x: Float, y: Float, now: Long): Boolean {
        if (now < swipeCooldownUntil) return false
        palmTrail.addLast(Triple(now, x, y))
        while (palmTrail.isNotEmpty() && now - palmTrail.first().first > SWIPE_WINDOW_MS) palmTrail.removeFirst()
        if (palmTrail.size < 3) return false
        val (_, x0, y0) = palmTrail.first()
        val dx = x - x0
        val dy = y - y0
        if (abs(dx) > SWIPE_MIN_DIST && abs(dx) > abs(dy) * 2f) {
            val g = if (dx < 0) BuiltInGesture.SWIPE_LEFT else BuiltInGesture.SWIPE_RIGHT
            palmTrail.clear()
            swipeCooldownUntil = now + SWIPE_COOLDOWN_MS
            // Swallow the palm hold so Home doesn't also fire.
            firedForStable = true
            findSlot(g.id, ControlBridge.surface?.foregroundPackage)?.let { fire(it.action, now) }
            return true
        }
        return false
    }

    // ------------------------------------------------------------------ helpers

    private fun updateStable(raw: String?, h: HandFrame, now: Long) {
        if (raw == candidate) candidateFrames++ else { candidate = raw; candidateFrames = 1 }
        val c = h[HandFrame.WRIST].mid(h[HandFrame.MIDDLE_MCP])
        if (candidateFrames >= STABLE_FRAMES && candidate != stable) {
            val old = stable
            stable = candidate
            stableSince = now
            stableX = c.x; stableY = c.y
            firedForStable = false
            onStableChanged(old, stable, now)
        } else if (stable != null && !firedForStable) {
            // Discrete gestures must be held fairly still; moving restarts the hold timer.
            if (hypot(c.x - stableX, c.y - stableY) > h.handSize * STILLNESS) {
                stableSince = now; stableX = c.x; stableY = c.y
            }
        }
    }

    private fun onStableChanged(old: String?, new: String?, now: Long) {
        if (old == BuiltInGesture.FIST.id) endDrag()
        if (new == BuiltInGesture.PINCH.id || new == BuiltInGesture.POINT_THUMB.id) {
            freezeUntil = now + CLICK_FREEZE_MS
        }
        if (new != BuiltInGesture.TWO_FINGERS.id) { scrollAccum = 0f; lastScrollY = Float.NaN }
    }

    private fun onNoHand(now: Long) {
        EngineBus.poseLabel.value = null
        endDrag()
        resetTracking()
        if (mode == EngineMode.ACTIVE) {
            style(if (now - lastHandSeen > HIDE_CURSOR_AFTER_MS) CursorStyle.HIDDEN else CursorStyle.LOST)
        }
        val idleMs = config.wake.idleSleepSec * 1000L
        if (mode == EngineMode.ACTIVE && lastHandSeen > 0 && now - lastHandSeen > idleMs) {
            host.requestMode(EngineMode.STANDBY)
        }
    }

    private fun resetTracking() {
        candidate = null; candidateFrames = 0
        stable = null
        clutch()
        palmTrail.clear()
        lastScrollY = Float.NaN; scrollAccum = 0f
    }

    private fun endDrag() {
        if (dragging) { dragging = false; ControlBridge.surface?.dragEnd() }
    }

    private fun findSlot(gestureId: String, pkg: String?): Slot? {
        val candidates = config.slots.filter { it.enabled && it.gestureId == gestureId }
        return candidates.firstOrNull { it.appPackage != null && it.appPackage == pkg }
            ?: candidates.firstOrNull { it.appPackage == null }
    }

    private fun fire(action: Action, now: Long) {
        lastAnyFireAt = now
        EngineBus.lastAction.value = action.label
        when (action) {
            Action.Sleep -> { host.haptic(true); host.requestMode(EngineMode.STANDBY) }
            Action.TurnOff -> { host.haptic(true); host.requestMode(EngineMode.OFF) }
            Action.RecenterCursor -> ControlBridge.surface?.recenterCursor()
            Action.None -> Unit
            else -> ControlBridge.surface?.perform(action)
        }
    }

    private fun style(s: CursorStyle) {
        if (s != cursorStyle) { cursorStyle = s; ControlBridge.surface?.setCursorStyle(s) }
    }

    private fun labelFor(id: String?, cfg: AppConfig): String? = when {
        id == null -> null
        id.startsWith("builtin:") -> BuiltInGesture.fromId(id)?.label
        else -> cfg.customGestures.firstOrNull { it.id == id }?.name
    }

    companion object {
        private val CURSOR_POSES = setOf(BuiltInGesture.POINT, BuiltInGesture.POINT_THUMB, BuiltInGesture.PINCH)
        const val STABLE_FRAMES = 3
        const val CLICK_FREEZE_MS = 160L
        const val FIST_DRAG_DELAY_MS = 350L
        const val GLOBAL_COOLDOWN_MS = 220L
        const val SCROLL_EMIT_MS = 110L
        const val SCROLL_DEADZONE = 0.006f
        const val SWIPE_WINDOW_MS = 320L
        const val SWIPE_MIN_DIST = 0.22f
        const val SWIPE_COOLDOWN_MS = 800L
        const val STILLNESS = 0.45f
        const val HIDE_CURSOR_AFTER_MS = 3000L
    }
}
