// AirPoint by Chever3d
package com.chever3d.airpoint

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.chever3d.airpoint.data.ConfigRepository

class AirPointApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ConfigRepository.get(this)
        val channel = NotificationChannel(
            CHANNEL_ENGINE, getString(R.string.channel_engine), NotificationManager.IMPORTANCE_LOW,
        ).apply { setShowBadge(false) }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    companion object {
        const val CHANNEL_ENGINE = "engine"
    }
}
