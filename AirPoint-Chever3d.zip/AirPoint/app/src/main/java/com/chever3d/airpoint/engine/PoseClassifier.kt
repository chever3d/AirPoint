// AirPoint by Chever3d
package com.chever3d.airpoint.engine

import com.chever3d.airpoint.data.BuiltInGesture
import com.chever3d.airpoint.engine.HandFrame.Companion.INDEX_MCP
import com.chever3d.airpoint.engine.HandFrame.Companion.INDEX_PIP
import com.chever3d.airpoint.engine.HandFrame.Companion.INDEX_TIP
import com.chever3d.airpoint.engine.HandFrame.Companion.MIDDLE_MCP
import com.chever3d.airpoint.engine.HandFrame.Companion.MIDDLE_PIP
import com.chever3d.airpoint.engine.HandFrame.Companion.MIDDLE_TIP
import com.chever3d.airpoint.engine.HandFrame.Companion.PINKY_MCP
import com.chever3d.airpoint.engine.HandFrame.Companion.PINKY_PIP
import com.chever3d.airpoint.engine.HandFrame.Companion.PINKY_TIP
import com.chever3d.airpoint.engine.HandFrame.Companion.RING_MCP
import com.chever3d.airpoint.engine.HandFrame.Companion.RING_PIP
import com.chever3d.airpoint.engine.HandFrame.Companion.RING_TIP
import com.chever3d.airpoint.engine.HandFrame.Companion.THUMB_MCP
import com.chever3d.airpoint.engine.HandFrame.Companion.THUMB_TIP
import com.chever3d.airpoint.engine.HandFrame.Companion.WRIST

/**
 * Rule-based static pose recogniser. Works on distances relative to hand size, so it is
 * independent of how far the hand is from the camera and of hand rotation in the image plane.
 * Motion gestures (swipes) are detected by [GestureEngine], not here.
 */
object PoseClassifier {

    data class Fingers(
        val thumb: Boolean,
        val index: Boolean,
        val middle: Boolean,
        val ring: Boolean,
        val pinky: Boolean,
        val pinch: Boolean,
    )

    fun fingers(h: HandFrame): Fingers {
        val s = h.handSize
        val w = h[WRIST]
        fun extended(tip: Int, pip: Int, mcp: Int): Boolean {
            // Tip clearly further from the wrist than the middle joint, and finger fairly straight.
            val tipFar = w.dist(h[tip]) > w.dist(h[pip]) * 1.12f
            val straight = h[mcp].dist(h[tip]) > s * 0.55f
            return tipFar && straight
        }
        // Thumb: tip far from the base of the index and from the palm centre.
        val palmCentre = h[WRIST].mid(h[MIDDLE_MCP])
        val thumbOut = h[THUMB_TIP].dist(h[INDEX_MCP]) > s * 0.55f &&
            h[THUMB_TIP].dist(palmCentre) > s * 0.75f
        // Pinch needs the index finger reaching out to the thumb; in a fist the thumb also
        // touches the curled index, which must not count as a pinch.
        val indexReaching = h[INDEX_MCP].dist(h[INDEX_TIP]) > s * 0.4f
        val pinch = indexReaching && h[THUMB_TIP].dist(h[INDEX_TIP]) < s * 0.28f
        return Fingers(
            thumb = thumbOut && !pinch,
            index = extended(INDEX_TIP, INDEX_PIP, INDEX_MCP),
            middle = extended(MIDDLE_TIP, MIDDLE_PIP, MIDDLE_MCP),
            ring = extended(RING_TIP, RING_PIP, RING_MCP),
            pinky = extended(PINKY_TIP, PINKY_PIP, PINKY_MCP),
            pinch = pinch,
        )
    }

    /** Returns the best matching built-in static pose, or null when unsure. */
    fun classify(h: HandFrame): BuiltInGesture? {
        val f = fingers(h)
        val s = h.handSize
        val i = f.index; val m = f.middle; val r = f.ring; val p = f.pinky

        // OK sign: thumb-index circle with the other three fingers up.
        if (f.pinch && m && r && p) return BuiltInGesture.OK
        // Pinch: thumb-index touch, other fingers relaxed/curled.
        if (f.pinch && !(m && r && p)) return BuiltInGesture.PINCH

        if (i && m && r && p && f.thumb) return BuiltInGesture.PALM
        if (i && m && r && !p) return BuiltInGesture.THREE
        if (i && m && !r && !p) return BuiltInGesture.TWO_FINGERS
        if (i && !m && !r && p) return BuiltInGesture.ROCK
        if (i && !m && !r && !p) return if (f.thumb) BuiltInGesture.POINT_THUMB else BuiltInGesture.POINT
        if (!i && !m && !r && p) return BuiltInGesture.PINKIE

        if (!i && !m && !r && !p) {
            if (f.thumb) {
                // Thumbs up / down: compare thumb tip height to its knuckle (image y grows downward).
                val dy = h[THUMB_TIP].y - h[THUMB_MCP].y
                if (dy < -s * 0.35f) return BuiltInGesture.THUMBS_UP
                if (dy > s * 0.35f) return BuiltInGesture.THUMBS_DOWN
                return null
            }
            return BuiltInGesture.FIST
        }
        return null
    }
}
