// AirPoint by Chever3d
package com.chever3d.airpoint.engine

import kotlinx.coroutines.flow.MutableStateFlow

enum class EngineMode { OFF, STANDBY, ACTIVE }

/**
 * Live state shared between the engine service, the accessibility service and the UI
 * (all in one process). Read-only for the UI except the two request flags at the bottom.
 */
object EngineBus {
    val mode = MutableStateFlow(EngineMode.OFF)
    val hand = MutableStateFlow<HandFrame?>(null)
    val poseLabel = MutableStateFlow<String?>(null)
    val lastAction = MutableStateFlow<String?>(null)
    val fps = MutableStateFlow(0f)
    val error = MutableStateFlow<String?>(null)
    val wakeWordReady = MutableStateFlow(false)

    /** UI sets this while recording a custom gesture so nothing fires. */
    val suppressActions = MutableStateFlow(false)

    /** UI sets this to make the accessibility service capture the next key press. */
    val learningKey = MutableStateFlow(false)
}
