// AirPoint by Chever3d
package com.chever3d.airpoint.engine

import kotlin.math.hypot

/**
 * One landmark in camera space, mirrored so it matches the user's own view.
 * Units are image widths on BOTH axes (x in 0..1, y in 0..[HandFrame.aspect]) so distances are true
 * to shape whatever the camera aspect ratio is.
 */
data class Pt(val x: Float, val y: Float, val z: Float = 0f) {
    fun dist(o: Pt): Float = hypot(x - o.x, y - o.y)
    fun mid(o: Pt): Pt = Pt((x + o.x) / 2f, (y + o.y) / 2f, (z + o.z) / 2f)
}

/** One detected hand in one camera frame. */
data class HandFrame(
    val points: List<Pt>, // 21 MediaPipe landmarks
    val isRightHand: Boolean,
    val timestampMs: Long,
    /** Image height / width. */
    val aspect: Float = 4f / 3f,
) {
    operator fun get(i: Int): Pt = points[i]

    /** Wrist to middle-finger knuckle: a scale reference that does not change with finger pose. */
    val handSize: Float get() = points[WRIST].dist(points[MIDDLE_MCP]).coerceAtLeast(1e-4f)

    companion object {
        const val WRIST = 0
        const val THUMB_CMC = 1; const val THUMB_MCP = 2; const val THUMB_IP = 3; const val THUMB_TIP = 4
        const val INDEX_MCP = 5; const val INDEX_PIP = 6; const val INDEX_DIP = 7; const val INDEX_TIP = 8
        const val MIDDLE_MCP = 9; const val MIDDLE_PIP = 10; const val MIDDLE_DIP = 11; const val MIDDLE_TIP = 12
        const val RING_MCP = 13; const val RING_PIP = 14; const val RING_DIP = 15; const val RING_TIP = 16
        const val PINKY_MCP = 17; const val PINKY_PIP = 18; const val PINKY_DIP = 19; const val PINKY_TIP = 20

        /** Bone pairs for drawing a hand skeleton. */
        val CONNECTIONS = listOf(
            0 to 1, 1 to 2, 2 to 3, 3 to 4,
            0 to 5, 5 to 6, 6 to 7, 7 to 8,
            5 to 9, 9 to 10, 10 to 11, 11 to 12,
            9 to 13, 13 to 14, 14 to 15, 15 to 16,
            13 to 17, 0 to 17, 17 to 18, 18 to 19, 19 to 20,
        )
    }
}
