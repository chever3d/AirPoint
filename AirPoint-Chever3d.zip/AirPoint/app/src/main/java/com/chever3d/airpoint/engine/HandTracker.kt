// AirPoint by Chever3d
package com.chever3d.airpoint.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.util.Log
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult

/**
 * Thin wrapper around MediaPipe Hand Landmarker (on-device, 21 points per hand).
 * Frames are rotated upright and mirrored so landmarks match what the user sees,
 * then converted to isotropic coordinates (see [Pt]).
 */
class HandTracker(
    context: Context,
    private val onResult: (HandFrame?, Long) -> Unit,
    private val onError: (String) -> Unit,
) {
    private val landmarker: HandLandmarker = create(context, Delegate.GPU)
        ?: create(context, Delegate.CPU)
        ?: throw IllegalStateException("Could not load hand_landmarker.task")

    @Volatile private var aspect = 4f / 3f

    private fun create(context: Context, delegate: Delegate): HandLandmarker? = try {
        val base = BaseOptions.builder()
            .setModelAssetPath(MODEL)
            .setDelegate(delegate)
            .build()
        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setNumHands(1)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setResultListener { result, _ -> deliver(result) }
            .setErrorListener { e -> onError(e.message ?: "Hand tracker error") }
            .build()
        HandLandmarker.createFromOptions(context, options)
    } catch (t: Throwable) {
        Log.w(TAG, "HandLandmarker with $delegate failed", t)
        null
    }

    /** Consumes and closes [proxy]. [timestampMs] must keep increasing. */
    fun detect(proxy: ImageProxy, timestampMs: Long) {
        val upright: Bitmap
        try {
            val src = proxy.toBitmap()
            val m = Matrix().apply {
                postRotate(proxy.imageInfo.rotationDegrees.toFloat())
                postScale(-1f, 1f) // front camera: mirror to the user's point of view
            }
            upright = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, false)
        } finally {
            proxy.close()
        }
        aspect = upright.height.toFloat() / upright.width.toFloat()
        try {
            landmarker.detectAsync(BitmapImageBuilder(upright).build(), timestampMs)
        } catch (t: Throwable) {
            Log.w(TAG, "detectAsync failed", t)
        }
    }

    private fun deliver(result: HandLandmarkerResult) {
        val ts = result.timestampMs()
        val hands = result.landmarks()
        if (hands.isEmpty()) { onResult(null, ts); return }
        val a = aspect
        val points = hands[0].map { Pt(it.x(), it.y() * a, it.z()) }
        val label = result.handedness().firstOrNull()?.firstOrNull()?.categoryName() ?: "Right"
        onResult(HandFrame(points, isRightHand = label.equals("Right", true), timestampMs = ts, aspect = a), ts)
    }

    fun close() = runCatching { landmarker.close() }

    companion object {
        private const val TAG = "AirPoint/HandTracker"
        const val MODEL = "hand_landmarker.task"
    }
}
