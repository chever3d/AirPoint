// AirPoint by Chever3d
package com.chever3d.airpoint.control

import android.accessibilityservice.AccessibilityService
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.PointF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import com.chever3d.airpoint.data.Action
import com.chever3d.airpoint.data.ConfigRepository
import com.chever3d.airpoint.engine.EngineBus
import com.chever3d.airpoint.engine.EngineMode
import com.chever3d.airpoint.engine.GestureEngineService
import com.chever3d.airpoint.wake.EngineLauncher

/**
 * The only component Android lets inject touches and system actions. It:
 *  - draws the cursor overlay
 *  - performs taps / swipes / Back / Home… for the engine
 *  - watches hardware keys for the wake triggers
 *  - tracks the foreground app for per-app gesture profiles
 *
 * Turning this service on/off with the system Accessibility shortcut (hold both volume keys)
 * also turns gesture control on/off.
 */
class AirPointAccessibilityService : AccessibilityService(), ControlSurface {

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var repo: ConfigRepository
    private lateinit var executor: ActionExecutor
    private lateinit var keys: HardwareKeyTrigger
    private var overlay: CursorOverlayView? = null

    private var screenW = 1080
    private var screenH = 2400
    private var cx = 0f
    private var cy = 0f

    private var dragging = false
    private var dragStartedAt = 0L
    private val dragPath = ArrayList<PointF>()

    @Volatile override var foregroundPackage: String? = null
        private set

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        repo = ConfigRepository.get(this)
        executor = ActionExecutor(this)
        keys = HardwareKeyTrigger(
            settings = { repo.config.value.wake },
            onToggle = { EngineLauncher.toggle(this) },
            onLearned = { code, name ->
                repo.update { it.copy(wake = it.wake.copy(learnedKeyCode = code, learnedKeyName = name)) }
            },
            adjustVolume = { executor.adjustVolumeFromKey(it) },
        )
        measureScreen()
        recenterCursor()
        addOverlay()
        ControlBridge.surface = this

        // Turned on via the accessibility shortcut (both volume keys)? Start gestures right away.
        // Skipped shortly after boot, when Android reconnects enabled services by itself.
        val bootedLongAgo = SystemClock.elapsedRealtime() > 3 * 60 * 1000
        if (repo.config.value.wake.startOnShortcut && bootedLongAgo && EngineBus.mode.value == EngineMode.OFF) {
            main.postDelayed({ EngineLauncher.activate(this) }, 300)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        foregroundPackage = pkg
    }

    override fun onKeyEvent(event: KeyEvent): Boolean = keys.onKeyEvent(event)

    override fun onInterrupt() = Unit

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!::wm.isInitialized) return
        measureScreen()
        cx = cx.coerceIn(0f, screenW - 1f); cy = cy.coerceIn(0f, screenH - 1f)
        overlay?.moveTo(cx, cy)
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        teardown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    private fun teardown() {
        if (ControlBridge.surface === this) ControlBridge.surface = null
        overlay?.let { runCatching { wm.removeView(it) } }
        overlay = null
        // Service switched off (e.g. via the shortcut) -> gestures off too.
        if (EngineBus.mode.value != EngineMode.OFF) {
            runCatching { startService(GestureEngineService.intent(this, GestureEngineService.ACTION_STOP)) }
        }
    }

    // ------------------------------------------------------------------ ControlSurface

    override fun moveCursorBy(dx: Float, dy: Float) = onMain {
        cx = (cx + dx * screenW).coerceIn(0f, screenW - 1f)
        cy = (cy + dy * screenW).coerceIn(0f, screenH - 1f)
        cursorMoved()
    }

    override fun setCursorAt(xFrac: Float, yFrac: Float) = onMain {
        cx = xFrac * (screenW - 1); cy = yFrac * (screenH - 1)
        cursorMoved()
    }

    override fun recenterCursor() = onMain {
        cx = screenW / 2f; cy = screenH / 2f
        overlay?.moveTo(cx, cy)
    }

    override fun setCursorStyle(style: CursorStyle) = onMain {
        overlay?.radiusPx = repo.config.value.cursor.cursorSizeDp / 2f * resources.displayMetrics.density
        overlay?.style = style
    }

    override fun perform(action: Action) = onMain {
        overlay?.pulse()
        executor.perform(action, cx, cy, screenW, screenH)
    }

    override fun scrollBy(dy: Float) = onMain {
        executor.scroll(cx, cy, dy * screenW, screenH)
    }

    override fun dragStart() = onMain {
        dragging = true
        dragStartedAt = SystemClock.uptimeMillis()
        dragPath.clear()
        dragPath += PointF(cx, cy)
    }

    override fun dragEnd() = onMain {
        if (!dragging) return@onMain
        dragging = false
        executor.drag(ArrayList(dragPath), SystemClock.uptimeMillis() - dragStartedAt)
        dragPath.clear()
    }

    // ------------------------------------------------------------------ helpers

    private fun cursorMoved() {
        overlay?.moveTo(cx, cy)
        if (dragging) {
            val last = dragPath.lastOrNull()
            if (last == null || kotlin.math.hypot(last.x - cx, last.y - cy) > 4f) dragPath += PointF(cx, cy)
        }
    }

    private inline fun onMain(crossinline block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else main.post { block() }
    }

    private fun addOverlay() {
        if (overlay != null) return
        val view = CursorOverlayView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        runCatching { wm.addView(view, lp); overlay = view; view.moveTo(cx, cy) }
    }

    private fun measureScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            screenW = b.width(); screenH = b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            screenW = dm.widthPixels; screenH = dm.heightPixels
        }
    }
}
