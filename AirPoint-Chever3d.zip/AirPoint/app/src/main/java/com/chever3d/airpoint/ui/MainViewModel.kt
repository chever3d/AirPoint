// AirPoint by Chever3d
package com.chever3d.airpoint.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.chever3d.airpoint.data.Action
import com.chever3d.airpoint.data.AppConfig
import com.chever3d.airpoint.data.ConfigRepository
import com.chever3d.airpoint.data.CursorSettings
import com.chever3d.airpoint.data.CustomGesture
import com.chever3d.airpoint.data.DefaultConfig
import com.chever3d.airpoint.data.Slot
import com.chever3d.airpoint.data.WakeSettings
import com.chever3d.airpoint.engine.CustomGestureMatcher
import com.chever3d.airpoint.engine.EngineBus
import com.chever3d.airpoint.engine.EngineMode
import com.chever3d.airpoint.wake.EngineLauncher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID

data class AppEntry(val packageName: String, val label: String)

sealed interface RecordState {
    data class Countdown(val seconds: Int) : RecordState
    data class Capturing(val progress: Float) : RecordState
    data class Failed(val reason: String) : RecordState
    data object Done : RecordState
}

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = ConfigRepository.get(app)
    val config: StateFlow<AppConfig> = repo.config

    val mode = EngineBus.mode
    val hand = EngineBus.hand
    val pose = EngineBus.poseLabel
    val fps = EngineBus.fps
    val lastAction = EngineBus.lastAction
    val error = EngineBus.error
    val learningKey = EngineBus.learningKey

    // ------------------------------------------------------------------ engine

    fun toggleEngine(context: Context) {
        if (mode.value == EngineMode.OFF) EngineLauncher.activate(context) else EngineLauncher.stop(context)
    }

    fun clearError() { EngineBus.error.value = null }

    // ------------------------------------------------------------------ slots

    fun saveSlot(slot: Slot) = repo.update { cfg ->
        val exists = cfg.slots.any { it.id == slot.id }
        cfg.copy(slots = if (exists) cfg.slots.map { if (it.id == slot.id) slot else it } else cfg.slots + slot)
    }

    fun deleteSlot(id: String) = repo.update { cfg -> cfg.copy(slots = cfg.slots.filterNot { it.id == id }) }

    fun setSlotEnabled(id: String, enabled: Boolean) = repo.update { cfg ->
        cfg.copy(slots = cfg.slots.map { if (it.id == id) it.copy(enabled = enabled) else it })
    }

    fun resetSlots() = repo.update { it.copy(slots = DefaultConfig.slots) }

    fun newSlot(gestureId: String): Slot =
        Slot(id = "s_" + UUID.randomUUID().toString().take(8), gestureId = gestureId, action = Action.None)

    // ------------------------------------------------------------------ settings

    fun updateCursor(transform: (CursorSettings) -> CursorSettings) =
        repo.update { it.copy(cursor = transform(it.cursor)) }

    fun updateWake(transform: (WakeSettings) -> WakeSettings) =
        repo.update { it.copy(wake = transform(it.wake)) }

    fun startLearningKey() { EngineBus.learningKey.value = true }
    fun cancelLearningKey() { EngineBus.learningKey.value = false }
    fun clearLearnedKey() = updateWake { it.copy(learnedKeyCode = -1, learnedKeyName = "") }

    // ------------------------------------------------------------------ custom gestures

    private val _record = MutableStateFlow<RecordState?>(null)
    val record: StateFlow<RecordState?> = _record.asStateFlow()

    /** Countdown, then captures ~40 frames of the held pose and saves it as a new gesture + slot. */
    fun recordGesture(context: Context, name: String) {
        viewModelScope.launch {
            if (mode.value != EngineMode.ACTIVE) EngineLauncher.activate(context)
            EngineBus.suppressActions.value = true
            try {
                for (s in 3 downTo 1) { _record.value = RecordState.Countdown(s); delay(1000) }
                val samples = ArrayList<List<Float>>()
                var lastTs = -1L
                val ok = withTimeoutOrNull(12_000) {
                    while (samples.size < SAMPLES) {
                        val h = EngineBus.hand.value
                        if (h != null && h.timestampMs != lastTs) {
                            lastTs = h.timestampMs
                            samples += CustomGestureMatcher.normalise(h)
                            _record.value = RecordState.Capturing(samples.size / SAMPLES.toFloat())
                        }
                        delay(40)
                    }
                    true
                }
                if (ok == null) {
                    _record.value = RecordState.Failed("Couldn't see your hand clearly. Try more light and keep it in frame.")
                    return@launch
                }
                val g = CustomGesture(id = "custom:" + UUID.randomUUID().toString().take(8), name = name.trim(), samples = samples)
                repo.update { cfg ->
                    cfg.copy(
                        customGestures = cfg.customGestures + g,
                        slots = cfg.slots + newSlot(g.id),
                    )
                }
                _record.value = RecordState.Done
            } finally {
                EngineBus.suppressActions.value = false
            }
        }
    }

    fun dismissRecord() { _record.value = null }

    fun deleteCustomGesture(id: String) = repo.update { cfg ->
        cfg.copy(
            customGestures = cfg.customGestures.filterNot { it.id == id },
            slots = cfg.slots.filterNot { it.gestureId == id },
        )
    }

    // ------------------------------------------------------------------ apps

    suspend fun launchableApps(): List<AppEntry> = withContext(Dispatchers.IO) {
        val pm = getApplication<Application>().packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(intent, 0)
            .map { AppEntry(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    companion object {
        const val SAMPLES = 40
    }
}
