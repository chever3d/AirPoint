// AirPoint by Chever3d
package com.chever3d.airpoint.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.chever3d.airpoint.data.CursorMode
import com.chever3d.airpoint.ui.MainViewModel
import com.chever3d.airpoint.ui.components.ApCard
import com.chever3d.airpoint.ui.components.HandSkeleton
import com.chever3d.airpoint.ui.components.Pill
import com.chever3d.airpoint.ui.components.SectionHeader
import com.chever3d.airpoint.ui.components.SliderRow
import com.chever3d.airpoint.ui.theme.ApColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TuneScreen(vm: MainViewModel) {
    val config by vm.config.collectAsState()
    val hand by vm.hand.collectAsState()
    val pose by vm.pose.collectAsState()
    val c = config.cursor

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        Spacer(Modifier.height(20.dp))
        Text("Tune cursor", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Turn gestures on from Home, then adjust here and feel the change live.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        SectionHeader("Cursor mode")
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            val modes = CursorMode.entries
            modes.forEachIndexed { i, m ->
                SegmentedButton(
                    selected = c.mode == m,
                    onClick = { vm.updateCursor { it.copy(mode = m) } },
                    shape = SegmentedButtonDefaults.itemShape(i, modes.size),
                ) { Text(if (m == CursorMode.RELATIVE) "Touchpad" else "Direct") }
            }
        }
        Text(
            if (c.mode == CursorMode.RELATIVE) "Moves like a laptop touchpad. Change pose to lift and reposition your hand."
            else "Your hand position maps straight to the screen.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 6.dp),
        )

        SectionHeader("Feel")
        ApCard {
            if (c.mode == CursorMode.RELATIVE) {
                SliderRow("Speed", "%.1f×".format(c.sensitivity), c.sensitivity, 0.8f..5f) { v ->
                    vm.updateCursor { it.copy(sensitivity = v) }
                }
                SliderRow("Acceleration", "%.1f".format(c.acceleration), c.acceleration, 0f..2f,
                    hint = "Fast flicks go further, slow moves stay precise.") { v ->
                    vm.updateCursor { it.copy(acceleration = v) }
                }
            } else {
                SliderRow("Active area", "${(c.activeArea * 100).toInt()}%", c.activeArea, 0.3f..1f,
                    hint = "Smaller = less arm movement to reach the edges.") { v ->
                    vm.updateCursor { it.copy(activeArea = v) }
                }
            }
            SliderRow("Steadiness", "%.1f".format(c.smoothing), c.smoothing, 0.3f..4f,
                hint = "Left = steadier but laggy. Right = snappier but jittery.") { v ->
                vm.updateCursor { it.copy(smoothing = v) }
            }
            SliderRow("Cursor size", "${c.cursorSizeDp} dp", c.cursorSizeDp.toFloat(), 14f..44f, steps = 14) { v ->
                vm.updateCursor { it.copy(cursorSizeDp = v.toInt()) }
            }
        }

        SectionHeader("What the camera sees")
        HandSkeleton(hand)
        Spacer(Modifier.height(8.dp))
        Pill(pose?.let { "Recognised: $it" } ?: "No pose", if (pose != null) ApColors.Live else ApColors.MutedForeground,
            modifier = Modifier.align(Alignment.CenterHorizontally))

        SectionHeader("Tips")
        ApCard {
            Tip("Keep your hand 30–60 cm from the phone, palm facing the camera.")
            Tip("Good light in front of you beats light behind you.")
            Tip("Prop the phone up so the camera sees your hand without you reaching.")
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Tip(text: String) {
    Text("•  $text", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 4.dp))
}
