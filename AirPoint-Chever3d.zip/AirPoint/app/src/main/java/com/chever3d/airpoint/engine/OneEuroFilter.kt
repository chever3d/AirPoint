// AirPoint by Chever3d
package com.chever3d.airpoint.engine

import kotlin.math.PI
import kotlin.math.abs

/**
 * One-Euro filter (Casiez et al. 2012): heavy smoothing when the hand is still (kills jitter),
 * light smoothing when it moves fast (kills lag).
 */
class OneEuroFilter(
    var minCutoff: Float = 1.2f,
    var beta: Float = 0.02f,
    private val dCutoff: Float = 1.0f,
) {
    private var xPrev = Float.NaN
    private var dxPrev = 0f
    private var tPrev = 0L

    fun reset() { xPrev = Float.NaN; dxPrev = 0f; tPrev = 0L }

    fun filter(x: Float, tMs: Long): Float {
        if (xPrev.isNaN()) { xPrev = x; tPrev = tMs; return x }
        val dt = ((tMs - tPrev).coerceAtLeast(1)) / 1000f
        tPrev = tMs
        val dx = (x - xPrev) / dt
        val edx = lerp(dxPrev, dx, alpha(dCutoff, dt))
        dxPrev = edx
        val cutoff = minCutoff + beta * abs(edx)
        val result = lerp(xPrev, x, alpha(cutoff, dt))
        xPrev = result
        return result
    }

    private fun alpha(cutoff: Float, dt: Float): Float {
        val tau = 1f / (2f * PI.toFloat() * cutoff)
        return 1f / (1f + tau / dt)
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
}
