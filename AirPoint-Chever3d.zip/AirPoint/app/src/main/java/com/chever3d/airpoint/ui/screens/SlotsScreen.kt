// AirPoint by Chever3d
package com.chever3d.airpoint.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FiberManualRecord
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.chever3d.airpoint.data.Action
import com.chever3d.airpoint.data.AppConfig
import com.chever3d.airpoint.data.BuiltInGesture
import com.chever3d.airpoint.data.Slot
import com.chever3d.airpoint.ui.AppEntry
import com.chever3d.airpoint.ui.MainViewModel
import com.chever3d.airpoint.ui.RecordState
import com.chever3d.airpoint.ui.components.ApCard
import com.chever3d.airpoint.ui.components.ChoiceButton
import com.chever3d.airpoint.ui.components.HandSkeleton
import com.chever3d.airpoint.ui.components.Pill
import com.chever3d.airpoint.ui.components.SectionHeader
import com.chever3d.airpoint.ui.components.SliderRow
import com.chever3d.airpoint.ui.components.SwitchRow
import com.chever3d.airpoint.ui.theme.ApColors

private fun gestureName(id: String, cfg: AppConfig): String =
    BuiltInGesture.fromId(id)?.label ?: cfg.customGestures.firstOrNull { it.id == id }?.name ?: "Unknown"

private fun gestureHint(id: String): String =
    BuiltInGesture.fromId(id)?.hint ?: "Your recorded gesture"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SlotsScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val config by vm.config.collectAsState()
    var editing by remember { mutableStateOf<Slot?>(null) }
    var askName by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { Column {
            Spacer(Modifier.height(20.dp))
            Text("Gesture slots", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Pick a gesture, give it a job. Per-app slots win over global ones.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            SectionHeader("Fixed modes")
            ApCard {
                ModeRow(BuiltInGesture.POINT)
                HorizontalDivider(color = ApColors.Muted)
                ModeRow(BuiltInGesture.TWO_FINGERS)
                HorizontalDivider(color = ApColors.Muted)
                ModeRow(BuiltInGesture.FIST)
            }
            SectionHeader("Slots")
        } }
        items(config.slots, key = { it.id }) { slot ->
            SlotCard(slot, config, onClick = { editing = slot }, onToggle = { vm.setSlotEnabled(slot.id, it) })
        }
        item { Column {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { editing = vm.newSlot(BuiltInGesture.PINCH.id) },
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp)); Text("Add slot")
                }
                OutlinedButton(onClick = { askName = true }, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) {
                    Icon(Icons.Rounded.FiberManualRecord, contentDescription = null, tint = ApColors.Destructive)
                    Spacer(Modifier.width(6.dp)); Text("Record gesture")
                }
            }
            if (config.customGestures.isNotEmpty()) {
                SectionHeader("Recorded gestures")
                ApCard {
                    config.customGestures.forEach { g ->
                        Row(Modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(g.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                            Text("${g.samples.size} samples", style = MaterialTheme.typography.bodySmall, color = ApColors.MutedForeground)
                            IconButton(onClick = { vm.deleteCustomGesture(g.id) }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Delete ${g.name}")
                            }
                        }
                    }
                }
            }
            TextButton(onClick = vm::resetSlots, modifier = Modifier.heightIn(min = 48.dp)) { Text("Reset slots to defaults") }
            Spacer(Modifier.height(24.dp))
        } }
    }

    editing?.let { slot ->
        SlotEditor(
            initial = slot,
            config = config,
            vm = vm,
            isNew = config.slots.none { it.id == slot.id },
            onDismiss = { editing = null },
        )
    }
    if (askName) NameDialog(onDismiss = { askName = false }) { name -> askName = false; vm.recordGesture(context, name) }
    RecordOverlay(vm)
}

@Composable
private fun ModeRow(g: BuiltInGesture) {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(g.label, style = MaterialTheme.typography.titleSmall)
        Text(g.hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SlotCard(slot: Slot, cfg: AppConfig, onClick: () -> Unit, onToggle: (Boolean) -> Unit) {
    ApCard(Modifier.clickable(role = Role.Button, onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(gestureName(slot.gestureId, cfg), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Pill(slot.action.label)
                    if (slot.holdMs > 0) Pill("hold ${slot.holdMs} ms", ApColors.MutedForeground)
                    if (slot.repeat) Pill("repeat", ApColors.MutedForeground)
                }
                slot.appLabel?.let {
                    Spacer(Modifier.height(4.dp))
                    Text("Only in $it", style = MaterialTheme.typography.bodySmall, color = ApColors.Standby)
                }
            }
            Switch(
                checked = slot.enabled,
                onCheckedChange = onToggle,
                colors = SwitchDefaults.colors(checkedTrackColor = ApColors.Live, checkedThumbColor = ApColors.OnLive),
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SlotEditor(initial: Slot, config: AppConfig, vm: MainViewModel, isNew: Boolean, onDismiss: () -> Unit) {
    var slot by remember(initial.id) { mutableStateOf(initial) }
    var pickApp by remember { mutableStateOf<((AppEntry?) -> Unit)?>(null) }
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val gestureIds = BuiltInGesture.entries.filter { it.assignable }.map { it.id } + config.customGestures.map { it.id }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheet, containerColor = ApColors.Card) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding(),
        ) {
            Text(if (isNew) "New slot" else "Edit slot", style = MaterialTheme.typography.titleLarge)

            SectionHeader("Gesture")
            ChoiceButton(
                label = gestureName(slot.gestureId, config),
                options = gestureIds,
                optionLabel = { gestureName(it, config) },
                onPick = { slot = slot.copy(gestureId = it) },
            )
            Text(gestureHint(slot.gestureId), style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))

            SectionHeader("Action")
            Action.groups.forEach { (group, actions) ->
                Text(group, style = MaterialTheme.typography.labelMedium, color = ApColors.MutedForeground,
                    modifier = Modifier.padding(top = 8.dp, bottom = 2.dp))
                actions.forEach { a -> ActionRadio(a.label, slot.action == a) { slot = slot.copy(action = a) } }
            }
            val openApp = slot.action as? Action.OpenApp
            ActionRadio(openApp?.label ?: "Open an app…", openApp != null) {
                pickApp = { entry -> entry?.let { slot = slot.copy(action = Action.OpenApp(it.packageName, it.label)) } }
            }

            SectionHeader("Timing")
            val isMotion = BuiltInGesture.fromId(slot.gestureId)?.isMotion == true
            if (!isMotion) {
                SliderRow(
                    title = "Hold before firing",
                    valueText = if (slot.holdMs == 0) "instant" else "${slot.holdMs} ms",
                    value = slot.holdMs.toFloat(),
                    range = 0f..1500f,
                    steps = 29,
                    hint = "Longer = fewer accidents.",
                ) { slot = slot.copy(holdMs = (it / 50).toInt() * 50) }
                SwitchRow("Repeat while held", "Good for volume or scrolling actions.", slot.repeat) {
                    slot = slot.copy(repeat = it)
                }
            } else {
                Text("Swipes fire immediately.", style = MaterialTheme.typography.bodySmall, color = ApColors.MutedForeground)
            }

            SectionHeader("Where")
            ActionRadio("All apps", slot.appPackage == null) { slot = slot.copy(appPackage = null, appLabel = null) }
            ActionRadio(slot.appLabel?.let { "Only in $it" } ?: "Only in one app…", slot.appPackage != null) {
                pickApp = { entry -> entry?.let { slot = slot.copy(appPackage = it.packageName, appLabel = it.label) } }
            }

            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (!isNew) {
                    OutlinedButton(
                        onClick = { vm.deleteSlot(slot.id); onDismiss() },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    ) { Text("Delete", color = ApColors.Destructive) }
                }
                Button(onClick = { vm.saveSlot(slot); onDismiss() }, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) {
                    Text("Save")
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    pickApp?.let { callback ->
        AppPicker(vm, onDismiss = { pickApp = null }) { entry -> callback(entry); pickApp = null }
    }
}

@Composable
private fun ActionRadio(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun AppPicker(vm: MainViewModel, onDismiss: () -> Unit, onPick: (AppEntry?) -> Unit) {
    var apps by remember { mutableStateOf<List<AppEntry>?>(null) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { apps = vm.launchableApps() }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ApColors.Card,
        title = { Text("Choose app") },
        text = {
            Column {
                OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Search") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                val list = apps
                if (list == null) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                } else {
                    LazyColumn(Modifier.heightIn(max = 360.dp)) {
                        items(list.filter { it.label.contains(query, ignoreCase = true) }, key = { it.packageName }) { app ->
                            Text(
                                app.label,
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onPick(app) }
                                    .heightIn(min = 48.dp)
                                    .padding(vertical = 12.dp),
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun NameDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ApColors.Card,
        title = { Text("Record a gesture") },
        text = {
            Column {
                Text(
                    "Name it, then hold the pose steady in front of the camera for about 3 seconds. Tilt it slightly while recording for better accuracy.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value = name, onValueChange = { name = it.take(24) }, label = { Text("Name") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(name) }, enabled = name.isNotBlank()) { Text("Start") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun RecordOverlay(vm: MainViewModel) {
    val state by vm.record.collectAsState()
    val hand by vm.hand.collectAsState()
    val s = state ?: return
    AlertDialog(
        onDismissRequest = { if (s is RecordState.Done || s is RecordState.Failed) vm.dismissRecord() },
        containerColor = ApColors.Card,
        title = {
            Text(
                when (s) {
                    is RecordState.Countdown -> "Get ready… ${s.seconds}"
                    is RecordState.Capturing -> "Hold it…"
                    is RecordState.Failed -> "Didn't work"
                    RecordState.Done -> "Saved"
                },
            )
        },
        text = {
            Column {
                HandSkeleton(hand)
                Spacer(Modifier.height(12.dp))
                when (s) {
                    is RecordState.Capturing -> LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth())
                    is RecordState.Failed -> Text(s.reason, style = MaterialTheme.typography.bodyMedium)
                    RecordState.Done -> Text(
                        "Your gesture was added as a new slot. Tap it in the list to pick an action.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    is RecordState.Countdown -> Text("Show the pose to the camera.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = {
            if (s is RecordState.Done || s is RecordState.Failed) TextButton(onClick = vm::dismissRecord) { Text("OK") }
        },
    )
}
