// AirPoint by Chever3d
package com.chever3d.airpoint.control

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.PointF
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Build
import android.os.SystemClock
import android.view.KeyEvent
import com.chever3d.airpoint.data.Action
import kotlin.math.abs

/** Turns [Action]s into real touches and system actions through the accessibility service. */
class ActionExecutor(private val svc: AccessibilityService) {

    private val audio = svc.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val cameraManager = svc.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private var torchOn = false
    private val torchId: String? = runCatching {
        cameraManager.cameraIdList.firstOrNull { id ->
            val c = cameraManager.getCameraCharacteristics(id)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
    }.getOrNull()

    init {
        runCatching {
            cameraManager.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    if (cameraId == torchId) torchOn = enabled
                }
            }, null)
        }
    }

    // Scrolls are queued so a new one never cancels one still in flight.
    private var scrollInFlight = false
    private var pendingScroll = 0f
    private var pendingScrollX = 0f
    private var pendingScrollY = 0f

    fun perform(action: Action, x: Float, y: Float, w: Int, h: Int) {
        when (action) {
            Action.Tap -> tap(x, y, 40)
            Action.LongPress -> tap(x, y, 650)
            Action.DoubleTap -> doubleTap(x, y)
            Action.Back -> global(AccessibilityService.GLOBAL_ACTION_BACK)
            Action.Home -> global(AccessibilityService.GLOBAL_ACTION_HOME)
            Action.Recents -> global(AccessibilityService.GLOBAL_ACTION_RECENTS)
            Action.Notifications -> global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            Action.QuickSettings -> global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            Action.PowerMenu -> global(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)
            Action.Screenshot -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            }
            Action.LockScreen -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            }
            Action.SwipeUp -> swipe(w / 2f, h * 0.72f, w / 2f, h * 0.28f, 220)
            Action.SwipeDown -> swipe(w / 2f, h * 0.28f, w / 2f, h * 0.72f, 220)
            Action.SwipeLeft -> swipe(w * 0.85f, h / 2f, w * 0.15f, h / 2f, 220)
            Action.SwipeRight -> swipe(w * 0.15f, h / 2f, w * 0.85f, h / 2f, 220)
            Action.VolumeUp -> volume(AudioManager.ADJUST_RAISE)
            Action.VolumeDown -> volume(AudioManager.ADJUST_LOWER)
            Action.Mute -> volume(AudioManager.ADJUST_TOGGLE_MUTE)
            Action.PlayPause -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            Action.NextTrack -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
            Action.PrevTrack -> mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            Action.Flashlight -> torchId?.let { runCatching { cameraManager.setTorchMode(it, !torchOn) } }
            is Action.OpenApp -> svc.packageManager.getLaunchIntentForPackage(action.packageName)?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { svc.startActivity(it) }
            }
            // Handled by the engine itself.
            Action.None, Action.Sleep, Action.TurnOff, Action.RecenterCursor -> Unit
        }
    }

    /**
     * Drags content under (x, y) by [dyPx] without flinging: move, then hold still briefly
     * so the app sees zero release velocity.
     */
    fun scroll(x: Float, y: Float, dyPx: Float, h: Int) {
        if (scrollInFlight) {
            pendingScroll += dyPx; pendingScrollX = x; pendingScrollY = y
            return
        }
        val margin = h * 0.08f
        var startY = y
        var endY = y + dyPx
        // Keep the whole stroke on screen.
        if (endY > h - margin) { val shift = endY - (h - margin); startY -= shift; endY -= shift }
        if (endY < margin) { val shift = margin - endY; startY += shift; endY += shift }
        startY = startY.coerceIn(margin, h - margin)
        if (abs(endY - startY) < 2f) return

        val move = Path().apply { moveTo(x, startY); lineTo(x, endY) }
        val duration = (abs(endY - startY) * 1.6f).toLong().coerceIn(120, 600)
        val first = GestureDescription.StrokeDescription(move, 0, duration, true)
        scrollInFlight = true
        dispatch(first) { ok ->
            if (!ok) { scrollDone(h); return@dispatch }
            val hold = Path().apply { moveTo(x, endY); lineTo(x, endY + 0.5f) }
            dispatch(first.continueStroke(hold, 0, 70, false)) { scrollDone(h) }
        }
    }

    private fun scrollDone(h: Int) {
        scrollInFlight = false
        if (abs(pendingScroll) > 2f) {
            val d = pendingScroll; pendingScroll = 0f
            scroll(pendingScrollX, pendingScrollY, d, h)
        }
    }

    /** Long-press at the first point, then follow the recorded path (drag & drop, reordering). */
    fun drag(points: List<PointF>, durationMs: Long) {
        if (points.size < 2) return
        val p0 = points.first()
        val press = Path().apply { moveTo(p0.x, p0.y); lineTo(p0.x + 0.5f, p0.y) }
        val first = GestureDescription.StrokeDescription(press, 0, 550, true)
        dispatch(first) { ok ->
            if (!ok) return@dispatch
            val path = Path().apply {
                moveTo(p0.x + 0.5f, p0.y)
                for (i in 1 until points.size) lineTo(points[i].x, points[i].y)
            }
            dispatch(first.continueStroke(path, 0, durationMs.coerceIn(150, 8000), false)) {}
        }
    }

    // ------------------------------------------------------------------ primitives

    private fun tap(x: Float, y: Float, durationMs: Long) {
        val p = Path().apply { moveTo(x, y) }
        dispatch(GestureDescription.StrokeDescription(p, 0, durationMs, false)) {}
    }

    private fun doubleTap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 40))
            .addStroke(GestureDescription.StrokeDescription(p, 140, 40))
            .build()
        svc.dispatchGesture(g, null, null)
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatch(GestureDescription.StrokeDescription(p, 0, durationMs, false)) {}
    }

    private fun dispatch(stroke: GestureDescription.StrokeDescription, done: (Boolean) -> Unit) {
        val g = GestureDescription.Builder().addStroke(stroke).build()
        val ok = svc.dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) = done(true)
            override fun onCancelled(gestureDescription: GestureDescription?) = done(false)
        }, null)
        if (!ok) done(false)
    }

    private fun global(action: Int) { svc.performGlobalAction(action) }

    private fun volume(direction: Int) {
        audio.adjustSuggestedStreamVolume(direction, AudioManager.USE_DEFAULT_STREAM_TYPE, AudioManager.FLAG_SHOW_UI)
    }

    fun adjustVolumeFromKey(direction: Int) = volume(direction)

    private fun mediaKey(code: Int) {
        val t = SystemClock.uptimeMillis()
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
    }
}
