// AirPoint by Chever3d
package com.chever3d.airpoint.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

private val Context.dataStore by preferencesDataStore(name = "airpoint")

/**
 * Whole app configuration stored as one JSON blob. Small, versionable, and easy to export.
 * Shared by the UI, the engine service and the accessibility service (same process).
 */
class ConfigRepository private constructor(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val key = stringPreferencesKey("config_json")

    val config: StateFlow<AppConfig> = context.dataStore.data
        .map { prefs -> prefs[key]?.let(::decode) ?: AppConfig() }
        .stateIn(scope, SharingStarted.Eagerly, AppConfig())

    fun update(transform: (AppConfig) -> AppConfig) {
        scope.launch {
            context.dataStore.edit { prefs ->
                val current = prefs[key]?.let(::decode) ?: AppConfig()
                prefs[key] = json.encodeToString(AppConfig.serializer(), transform(current))
            }
        }
    }

    fun exportJson(): String = json.encodeToString(AppConfig.serializer(), config.value)

    private fun decode(raw: String): AppConfig? =
        runCatching { json.decodeFromString(AppConfig.serializer(), raw) }.getOrNull()

    companion object {
        private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = false }

        @Volatile private var instance: ConfigRepository? = null
        fun get(context: Context): ConfigRepository =
            instance ?: synchronized(this) {
                instance ?: ConfigRepository(context.applicationContext).also { instance = it }
            }
    }
}
