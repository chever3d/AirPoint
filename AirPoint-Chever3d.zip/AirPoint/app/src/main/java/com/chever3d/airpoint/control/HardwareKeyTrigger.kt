// AirPoint by Chever3d
package com.chever3d.airpoint.control

import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import com.chever3d.airpoint.data.WakeSettings
import com.chever3d.airpoint.engine.EngineBus

/**
 * Hardware-button wake triggers, fed by the accessibility service's key filter
 * (only delivered while the screen is on):
 *  - hold Volume Down ~0.6 s          -> toggle gestures (short press still lowers volume)
 *  - press Volume Up + Down together  -> toggle gestures
 *  - one learned key (BT clicker etc.) -> toggle gestures
 * "Hold both volume keys 3 s" is handled by Android itself via the accessibility shortcut.
 */
class HardwareKeyTrigger(
    private val settings: () -> WakeSettings,
    private val onToggle: () -> Unit,
    private val onLearned: (code: Int, name: String) -> Unit,
    private val adjustVolume: (direction: Int) -> Unit,
) {
    private val main = Handler(Looper.getMainLooper())

    private var downHeld = false
    private var upHeld = false
    private var downConsumed = false
    private var upConsumed = false
    private var longFired = false
    private var comboFired = false

    private val longPress = Runnable {
        longFired = true
        onToggle()
    }

    fun onKeyEvent(e: KeyEvent): Boolean {
        val code = e.keyCode

        // Learn mode: capture the next non-system key.
        if (EngineBus.learningKey.value) {
            if (e.action == KeyEvent.ACTION_DOWN && code !in reservedKeys) {
                EngineBus.learningKey.value = false
                onLearned(code, KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_"))
                return true
            }
            return code !in reservedKeys
        }

        val w = settings()

        if (w.learnedKeyCode != -1 && code == w.learnedKeyCode) {
            if (e.action == KeyEvent.ACTION_UP && e.repeatCount == 0) onToggle()
            return true
        }

        val isDown = code == KeyEvent.KEYCODE_VOLUME_DOWN
        val isUp = code == KeyEvent.KEYCODE_VOLUME_UP
        if (!isDown && !isUp) return false

        when (e.action) {
            KeyEvent.ACTION_DOWN -> {
                if (e.repeatCount > 0) return if (isDown) downConsumed else upConsumed
                if (isDown) downHeld = true else upHeld = true

                if (w.volumeCombo && downHeld && upHeld) {
                    main.removeCallbacks(longPress)
                    comboFired = true
                    onToggle()
                    if (isDown) downConsumed = true else upConsumed = true
                    return true
                }
                if (isDown && w.volumeDownHold) {
                    longFired = false
                    downConsumed = true
                    main.postDelayed(longPress, LONG_PRESS_MS)
                    return true
                }
                if (isUp && w.volumeCombo) {
                    // Wait for a possible combo; replay the volume change on release.
                    upConsumed = true
                    return true
                }
                if (isDown && w.volumeCombo) {
                    downConsumed = true
                    return true
                }
                return false
            }
            KeyEvent.ACTION_UP -> {
                if (isDown) {
                    downHeld = false
                    main.removeCallbacks(longPress)
                    val consumed = downConsumed
                    downConsumed = false
                    if (!consumed) return false
                    when {
                        comboFired -> { if (!upHeld) comboFired = false }
                        longFired -> longFired = false
                        else -> adjustVolume(AudioManager.ADJUST_LOWER)
                    }
                    return true
                } else {
                    upHeld = false
                    val consumed = upConsumed
                    upConsumed = false
                    if (!consumed) return false
                    if (comboFired) { if (!downHeld) comboFired = false } else adjustVolume(AudioManager.ADJUST_RAISE)
                    return true
                }
            }
        }
        return false
    }

    companion object {
        const val LONG_PRESS_MS = 600L
        val reservedKeys = setOf(
            KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_POWER,
            KeyEvent.KEYCODE_HOME, KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_APP_SWITCH,
        )
    }
}
