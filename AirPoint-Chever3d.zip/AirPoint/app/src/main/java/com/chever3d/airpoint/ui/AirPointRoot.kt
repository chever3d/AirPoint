// AirPoint by Chever3d
package com.chever3d.airpoint.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.PanTool
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.chever3d.airpoint.ui.screens.HomeScreen
import com.chever3d.airpoint.ui.screens.SlotsScreen
import com.chever3d.airpoint.ui.screens.TuneScreen
import com.chever3d.airpoint.ui.screens.WakeScreen
import com.chever3d.airpoint.ui.theme.ApColors

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "Home", Icons.Rounded.Home),
    Gestures("gestures", "Gestures", Icons.Rounded.PanTool),
    Wake("wake", "Wake", Icons.Rounded.PowerSettingsNew),
    Tune("tune", "Tune", Icons.Rounded.Tune),
}

@Composable
fun AirPointRoot(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = ApColors.Card) {
                Tab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = current == tab.route,
                        onClick = {
                            nav.navigate(tab.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = null) },
                        label = { Text(tab.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ApColors.OnLive,
                            indicatorColor = ApColors.Live,
                            selectedTextColor = ApColors.Live,
                            unselectedIconColor = ApColors.MutedForeground,
                            unselectedTextColor = ApColors.MutedForeground,
                        ),
                    )
                }
            }
        },
    ) { padding ->
        NavHost(nav, startDestination = Tab.Home.route, modifier = Modifier.padding(padding)) {
            composable(Tab.Home.route) { HomeScreen(vm) }
            composable(Tab.Gestures.route) { SlotsScreen(vm) }
            composable(Tab.Wake.route) { WakeScreen(vm) }
            composable(Tab.Tune.route) { TuneScreen(vm) }
        }
    }
}
