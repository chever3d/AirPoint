// AirPoint by Chever3d
package com.chever3d.airpoint.wake

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.chever3d.airpoint.engine.EngineBus
import com.chever3d.airpoint.engine.EngineMode
import com.chever3d.airpoint.engine.GestureEngineService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/** Quick Settings tile: one tap toggles gesture control. */
class GestureTileService : TileService() {

    private var job: Job? = null

    override fun onStartListening() {
        super.onStartListening()
        job = CoroutineScope(Dispatchers.Main).launch {
            EngineBus.mode.collect { render(it) }
        }
    }

    override fun onStopListening() {
        job?.cancel(); job = null
        super.onStopListening()
    }

    @SuppressLint("StartActivityAndCollapseDeprecated")
    override fun onClick() {
        super.onClick()
        if (EngineBus.mode.value != EngineMode.OFF) {
            EngineLauncher.stop(this)
            return
        }
        val intent = EngineLauncher.trampolineIntent(this, GestureEngineService.ACTION_ACTIVATE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startActivityAndCollapse(
                PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT),
            )
        } else {
            @Suppress("DEPRECATION") startActivityAndCollapse(intent)
        }
    }

    private fun render(mode: EngineMode) {
        val tile = qsTile ?: return
        tile.state = if (mode == EngineMode.OFF) Tile.STATE_INACTIVE else Tile.STATE_ACTIVE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.subtitle = when (mode) {
                EngineMode.ACTIVE -> "On"
                EngineMode.STANDBY -> "Standby"
                EngineMode.OFF -> "Off"
            }
        }
        tile.updateTile()
    }
}
