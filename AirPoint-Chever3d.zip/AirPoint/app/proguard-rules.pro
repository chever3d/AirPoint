# MediaPipe uses reflection / JNI
-keep class com.google.mediapipe.** { *; }
-dontwarn com.google.mediapipe.**
-keep class com.google.protobuf.** { *; }
-dontwarn com.google.protobuf.**
# Picovoice
-keep class ai.picovoice.** { *; }
# kotlinx.serialization
-keepattributes *Annotation*, InnerClasses
-keepclassmembers class com.chever3d.airpoint.data.** { *** Companion; *; }
