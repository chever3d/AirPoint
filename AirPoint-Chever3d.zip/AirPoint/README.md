# AirPoint — by Chever3d

Control your Android phone with hand gestures in front of the front camera.
Point to move a cursor, pinch to tap, pinkie for Back, palm for Home, and map any
gesture (including ones you record) to any action.

## Open & run

1. Open this folder in **Android Studio** (Ladybug or newer). Let Gradle sync.
2. Build once with internet on: the build downloads the MediaPipe hand model
   (`hand_landmarker.task`, ~7.5 MB) into `app/src/main/assets/` automatically.
3. Run on a real phone (Android 8.0+, front camera). Emulators can't really test this.
4. In the app: allow **Camera**, turn on the **AirPoint accessibility service**, allow notifications.
5. Tap the big ring on Home. Hold your hand 30–60 cm from the phone.

## Default gestures

| Gesture | Does |
|---|---|
| Point (index up) | Move cursor (touchpad style) |
| Pinch / Point + thumb out | Tap |
| Two fingers up, move | Scroll |
| Fist, hold & move, open | Drag (long-press drag) |
| Pinkie only | Back |
| Open palm, held still | Home |
| Palm swipe left / right | Recents / Notifications |
| Three fingers | Quick settings |
| Thumbs up / down (held) | Volume up / down (repeats) |
| OK sign | Screenshot |
| Rock (index + pinkie) | Pause gestures |

Everything except the three modes (point, two fingers, fist) lives in **Gestures → slots**:
change the gesture, action, hold time, repeat, or limit it to one app. **Record gesture**
captures any custom hand pose (40 samples, position/size/rotation/left-right independent).

## Turning it on and off

| Trigger | Notes |
|---|---|
| Hold both volume keys 3 s | Android's Accessibility shortcut. Settings → Accessibility → shortcut → AirPoint. Works everywhere, zero battery. |
| Hold Volume Down 0.6 s | Short press still changes volume. Screen on only. |
| Volume Up + Down tap | Optional combo. |
| Learned button | Bluetooth selfie clicker, headset button, remapped key — any key Android passes to apps. |
| Quick Settings tile | "Gestures" tile. |
| Wake gesture | Optional. In standby the camera checks 5×/s for the pose. |
| Wake word | Optional, offline (Picovoice Porcupine). See below. |

No hand for N seconds → standby (if a hands-free wake is on) or off. Screen off → always off.

### Wake word setup (optional)
1. Free AccessKey from https://console.picovoice.ai
2. Add to `local.properties`: `picovoice.accessKey=YOUR_KEY`
3. Built-in words: Jarvis, Computer, Porcupine, Bumblebee, Terminator…
4. Custom phrase (e.g. "Hey Chever"): train on the Picovoice console for Android, save as
   `app/src/main/assets/wake/custom_wake_word.ppn`, pick "Custom" in the app.

Battery note: unlike "OK Google" (dedicated low-power chip), a third-party wake word runs on the
main CPU, so it only listens during standby.

## How it's built

```
engine/   HandTracker (MediaPipe) → PoseClassifier + CustomGestureMatcher → GestureEngine
          GestureEngineService: foreground camera/mic service, ACTIVE / STANDBY / OFF
control/  AirPointAccessibilityService: cursor overlay, taps/swipes/global actions, key triggers
wake/     EngineLauncher (legal background start via WakeTrampolineActivity), QS tile, wake word
data/     Slots, actions, settings (DataStore JSON)
ui/       Jetpack Compose, 4 tabs: Home · Gestures · Wake · Tune
```

Design system (from ui-ux-pro-max): OLED dark, `#0F172A` background, `#22C55E` = live,
amber = standby, JetBrains Mono headings + IBM Plex Sans body, 48 dp touch targets.

## Known limits (v0.1)
- Drag replays the path when you open your fist (not live while dragging).
- Volume-key triggers only work with the screen on (Android limit).
- Some phones' maker-specific keys (AI/action buttons) never reach third-party apps.
- Play Store: declare the accessibility service as an accessibility tool and show a
  prominent disclosure before enabling it.

## Credits
Made by **Chever3d**. Fonts: JetBrains Mono and IBM Plex Sans (SIL OFL, see `licenses/`).
Hand tracking: Google MediaPipe. Wake word: Picovoice Porcupine.
